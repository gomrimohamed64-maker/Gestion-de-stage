<?php
$base_path = '';
if (strpos($_SERVER['PHP_SELF'], '/dashboards/') !== false) {
    $base_path = '../';
}
?>
    <footer class="bg-dark text-white pt-5 pb-4 mt-5">
        <div class="container">
            <div class="row g-4 mb-4">
                <div class="col-lg-4 col-md-6">
                    <div class="mb-3">
                        <span class="ey-logo fs-4">EY</span>
                    </div>
                    <p class="text-white-50 mb-3">Building a better working world</p>
                    <p class="text-white-50 small mb-3">
                        EY est un leader mondial de l'audit, du conseil, de la fiscalité et des transactions. 
                        Nous développons les talents pour construire un monde du travail meilleur.
                    </p>
                    <!-- Added social media icons with proper styling -->
                    <div class="d-flex gap-2">
                        <a href="#" class="btn btn-outline-light btn-sm rounded-circle" style="width: 36px; height: 36px; display: flex; align-items: center; justify-content: center;" title="LinkedIn">
                            <i class="bi bi-linkedin"></i>
                        </a>
                        <a href="#" class="btn btn-outline-light btn-sm rounded-circle" style="width: 36px; height: 36px; display: flex; align-items: center; justify-content: center;" title="Twitter">
                            <i class="bi bi-twitter"></i>
                        </a>
                        <a href="#" class="btn btn-outline-light btn-sm rounded-circle" style="width: 36px; height: 36px; display: flex; align-items: center; justify-content: center;" title="Facebook">
                            <i class="bi bi-facebook"></i>
                        </a>
                        <a href="#" class="btn btn-outline-light btn-sm rounded-circle" style="width: 36px; height: 36px; display: flex; align-items: center; justify-content: center;" title="Instagram">
                            <i class="bi bi-instagram"></i>
                        </a>
                    </div>
                </div>
                <!-- Expanded footer navigation with more links -->
                <div class="col-lg-2 col-md-6">
                    <h6 class="text-warning mb-3 fw-bold">Navigation</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="<?= $base_path ?>index.php" class="text-white-50 text-decoration-none small"><i class="bi bi-chevron-right small"></i> Accueil</a></li>
                        <li class="mb-2"><a href="<?= $base_path ?>stages.php" class="text-white-50 text-decoration-none small"><i class="bi bi-chevron-right small"></i> Stages</a></li>
                        <li class="mb-2"><a href="<?= $base_path ?>about.php" class="text-white-50 text-decoration-none small"><i class="bi bi-chevron-right small"></i> À propos</a></li>
                        <li class="mb-2"><a href="<?= $base_path ?>contact.php" class="text-white-50 text-decoration-none small"><i class="bi bi-chevron-right small"></i> Contact</a></li>
                        <li class="mb-2"><a href="<?= $base_path ?>faq.php" class="text-white-50 text-decoration-none small"><i class="bi bi-chevron-right small"></i> FAQ</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h6 class="text-warning mb-3 fw-bold">Nous Contacter</h6>
                    <ul class="list-unstyled text-white-50 small">
                        <li class="mb-2">
                            <i class="bi bi-geo-alt me-2 text-warning"></i> Centre-Ville de Tunis<br><span style="margin-left: 24px;">1000 Tunis, Tunisie</span>
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-envelope me-2 text-warning"></i> <a href="mailto:stages@ey.tn" class="text-white-50 text-decoration-none">stages@ey.tn</a>
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-telephone me-2 text-warning"></i> +216 71 961 100
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-clock me-2 text-warning"></i> Lun - Jeu: 8h - 17h
                        </li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h6 class="text-warning mb-3 fw-bold">Ressources</h6>
                    <ul class="list-unstyled small">
                        <li class="mb-2"><a href="#" class="text-white-50 text-decoration-none"><i class="bi bi-chevron-right small"></i> Politique de confidentialité</a></li>
                        <li class="mb-2"><a href="#" class="text-white-50 text-decoration-none"><i class="bi bi-chevron-right small"></i> Mentions légales</a></li>
                        <li class="mb-2"><a href="#" class="text-white-50 text-decoration-none"><i class="bi bi-chevron-right small"></i> Conditions d'utilisation</a></li>
                        <li class="mb-2"><a href="#" class="text-white-50 text-decoration-none"><i class="bi bi-chevron-right small"></i> Plan du site</a></li>
                    </ul>
                </div>
            </div>
            <hr class="my-4 bg-secondary">
            <!-- Enhanced footer bottom with better layout -->
            <div class="row align-items-center">
                <div class="col-12 text-center">
                    <p class="text-white-50 small mb-0">&copy; 2026 EY Tunisie - Tous droits réservés | Plateforme de Gestion des Stages</p>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
