<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Déterminer le chemin de base
$base_path = '';
if (strpos($_SERVER['PHP_SELF'], '/dashboards/') !== false) {
    $base_path = '../';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EY - Gestion des Stages</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="<?= $base_path ?>assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Enhanced navbar with notification and search features -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center fw-bold" href="<?= $base_path ?>index.php">
                <div class="ey-logo me-2" style="padding: 6px 14px; font-size: 1.1rem;">EY</div>
                <span class="d-none d-sm-inline fw-light">Stages</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= $base_path ?>index.php">
                            <i class="bi bi-house"></i> Accueil
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= $base_path ?>stages.php">
                            <i class="bi bi-briefcase"></i> Stages
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= $base_path ?>about.php">
                            <i class="bi bi-building"></i> À propos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= $base_path ?>contact.php">
                            <i class="bi bi-envelope"></i> Contact
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= $base_path ?>faq.php">
                            <i class="bi bi-question-circle"></i> FAQ
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <!-- Removed search bar -->
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="d-flex align-items-center">
                                    <div style="width: 32px; height: 32px; background: #ffe600; color: #2e2e38; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 0.9rem; margin-right: 8px;">
                                        <?= strtoupper(substr($_SESSION['prenom'][0], 0, 1) . substr($_SESSION['nom'][0], 0, 1)) ?>
                                    </div>
                                    <span class="d-none d-md-inline">
                                        <?= htmlspecialchars($_SESSION['prenom'] . ' ' . $_SESSION['nom']) ?>
                                    </span>
                                </div>
                                <span class="badge bg-warning text-dark ms-2 d-none d-md-inline" style="font-size: 0.7rem;">
                                    <?= ucfirst($_SESSION['role']) ?>
                                </span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><h6 class="dropdown-header">Mon compte</h6></li>
                                <li>
                                    <a class="dropdown-item" href="<?= $base_path ?>dashboard.php">
                                        <i class="bi bi-speedometer2 me-2"></i> Mon espace
                                    </a>
                                </li>
                                <?php if ($_SESSION['role'] === 'stagiaire'): ?>
                                <li>
                                    <a class="dropdown-item" href="<?= $base_path ?>dashboards/stagiaire-profil.php">
                                        <i class="bi bi-person me-2"></i> Mon profil
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="<?= $base_path ?>dashboards/stagiaire-projets.php">
                                        <i class="bi bi-kanban me-2"></i> Mes tâches
                                    </a>
                                </li>
                                <?php elseif ($_SESSION['role'] === 'encadrant'): ?>
                                <li>
                                    <a class="dropdown-item" href="<?= $base_path ?>dashboards/encadrant-projets.php">
                                        <i class="bi bi-kanban me-2"></i> Gestion projets
                                    </a>
                                </li>
                                <?php elseif ($_SESSION['role'] === 'admin'): ?>
                                <li>
                                    <a class="dropdown-item" href="<?= $base_path ?>dashboards/admin.php">
                                        <i class="bi bi-gear me-2"></i> Administration
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="<?= $base_path ?>dashboards/admin-rapports.php">
                                        <i class="bi bi-graph-up me-2"></i> Rapports
                                    </a>
                                </li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="<?= $base_path ?>logout.php">
                                        <i class="bi bi-box-arrow-right me-2"></i> Déconnexion
                                    </a>
                                </li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= $base_path ?>inscription.php">
                                <i class="bi bi-person-plus"></i> S'inscrire
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-warning ms-2 text-dark fw-600" href="<?= $base_path ?>connexion.php">
                                <i class="bi bi-box-arrow-in-right"></i> Connexion
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
