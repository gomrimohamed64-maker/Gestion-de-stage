<?php
require_once 'config/database.php';
include 'includes/header.php';

// Récupérer les stages ouverts
$pdo = getConnection();
$stmt = $pdo->query("SELECT * FROM stages WHERE statut = 'ouvert' ORDER BY date_creation DESC LIMIT 6");
$stages = $stmt->fetchAll();

// Statistiques
$totalStages = $pdo->query("SELECT COUNT(*) FROM stages WHERE statut = 'ouvert'")->fetchColumn();
$totalStagiaires = $pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'stagiaire'")->fetchColumn();
$totalEncadrants = $pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'encadrant'")->fetchColumn();
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container position-relative" style="z-index: 1;">
        <div class="row align-items-center">
            <div class="col-lg-7 animate-fadeInUp">
                <span class="badge bg-warning text-dark mb-3 px-3 py-2">
                    <i class="bi bi-star-fill me-1"></i> Opportunités de carrière
                </span>
                <h1 class="mb-4">Construisez votre <span class="highlight">avenir</span><br>avec EY</h1>
                <p class="lead mb-4">Rejoignez l'un des leaders mondiaux du conseil et de l'audit. Découvrez nos opportunités de stage et lancez votre carrière dans un environnement stimulant et innovant.</p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="stages.php" class="btn btn-ey btn-lg">
                        <i class="bi bi-search me-2"></i> Explorer les stages
                    </a>
                    <a href="inscription.php" class="btn btn-outline-ey btn-lg">
                        <i class="bi bi-person-plus me-2"></i> Créer un compte
                    </a>
                </div>
            </div>
            <div class="col-lg-5 mt-5 mt-lg-0">
                <div class="row g-4 text-center">
                    <div class="col-4">
                        <div class="stat-number"><?= $totalStages ?></div>
                        <p class="stat-label mb-0">Stages<br>disponibles</p>
                    </div>
                    <div class="col-4">
                        <div class="stat-number"><?= $totalStagiaires ?>+</div>
                        <p class="stat-label mb-0">Stagiaires<br>inscrits</p>
                    </div>
                    <div class="col-4">
                        <div class="stat-number"><?= $totalEncadrants ?></div>
                        <p class="stat-label mb-0">Encadrants<br>experts</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <span class="badge bg-dark mb-3 px-3 py-2">Pourquoi EY</span>
            <h2 class="fw-bold mb-3">Avantages de nos stages</h2>
        </div>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card card-feature border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="feature-icon mb-3">
                            <i class="bi bi-mortarboard"></i>
                        </div>
                        <h5 class="card-title fw-bold mb-3">Formation Continue</h5>
                        <p class="card-text text-muted mb-0">Développez vos compétences avec nos programmes de formation innovants et un accompagnement personnalisé par des experts.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-feature border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="feature-icon mb-3">
                            <i class="bi bi-briefcase"></i>
                        </div>
                        <h5 class="card-title fw-bold mb-3">Expérience Réelle</h5>
                        <p class="card-text text-muted mb-0">Travaillez sur des projets concrets aux côtés de professionnels expérimentés et gagnez une expérience précieuse.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-feature border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="feature-icon mb-3">
                            <i class="bi bi-graph-up"></i>
                        </div>
                        <h5 class="card-title fw-bold mb-3">Carrière Prometteuse</h5>
                        <p class="card-text text-muted mb-0">Accédez à des perspectives de carrière avec des opportunités d'évolution et d'embauche directe après votre stage.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- About Section -->
<section id="about" class="about-section py-5">
    <div class="container">
        <div class="text-center mb-5">
            <span class="badge bg-dark mb-3 px-3 py-2">Qui sommes-nous</span>
            <h2 class="fw-bold mb-3">À propos d'<span class="ey-logo">EY</span></h2>
            <p class="text-muted mx-auto" style="max-width: 600px;">Building a better working world - Notre mission est de contribuer à un monde du travail meilleur en développant la confiance dans les marchés et les économies.</p>
        </div>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="text-center p-4">
                    <div class="about-icon">
                        <i class="bi bi-globe"></i>
                    </div>
                    <h5 class="fw-bold mb-3">Présence mondiale</h5>
                    <p class="text-muted mb-0">Plus de 150 pays et 700 bureaux dans le monde avec 300 000+ collaborateurs passionnés.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center p-4">
                    <div class="about-icon">
                        <i class="bi bi-briefcase"></i>
                    </div>
                    <h5 class="fw-bold mb-3">Expertise diversifiée</h5>
                    <p class="text-muted mb-0">Audit, Consulting, Tax & Law, Strategy and Transactions - Des domaines variés pour votre développement.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center p-4">
                    <div class="about-icon">
                        <i class="bi bi-mortarboard"></i>
                    </div>
                    <h5 class="fw-bold mb-3">Formation continue</h5>
                    <p class="text-muted mb-0">Développez vos compétences avec nos programmes de formation innovants et un accompagnement personnalisé.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Stages Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <span class="badge bg-warning text-dark mb-2 px-3 py-2">Opportunités</span>
                <h2 class="fw-bold mb-0">Stages récents</h2>
            </div>
            <a href="stages.php" class="btn btn-outline-dark">
                Voir tous les stages <i class="bi bi-arrow-right ms-2"></i>
            </a>
        </div>
        <div class="row g-4">
            <?php foreach ($stages as $stage): ?>
            <div class="col-md-6 col-lg-4">
                <div class="card card-stage h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <span class="badge bg-dark"><?= htmlspecialchars($stage['departement']) ?></span>
                            <span class="badge bg-success"><?= $stage['places_disponibles'] ?> place(s)</span>
                        </div>
                        <h5 class="card-title fw-bold mb-3"><?= htmlspecialchars($stage['titre']) ?></h5>
                        <p class="card-text text-muted small"><?= substr(htmlspecialchars($stage['description']), 0, 120) ?>...</p>
                        <hr>
                        <div class="d-flex justify-content-between text-muted small">
                            <span><i class="bi bi-clock me-1"></i> <?= htmlspecialchars($stage['duree']) ?></span>
                            <span><i class="bi bi-geo-alt me-1"></i> <?= htmlspecialchars($stage['lieu'] ?? 'Tunis') ?></span>
                        </div>
                    </div>
                    <div class="card-footer bg-white border-0 pt-0">
                        <a href="stage-detail.php?id=<?= $stage['id'] ?>" class="btn btn-ey w-100">
                            <i class="bi bi-arrow-right me-2"></i> Voir les détails
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <span class="badge bg-dark mb-3 px-3 py-2">Témoignages</span>
            <h2 class="fw-bold mb-3">Ce que disent nos stagiaires</h2>
        </div>
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center mb-3">
                            <div class="avatar-testimonial me-3">A</div>
                            <div>
                                <h6 class="mb-0 fw-bold">Ahmed Ben Ali</h6>
                                <small class="text-muted">Développeur Backend</small>
                            </div>
                        </div>
                        <p class="card-text text-muted mb-3">Le stage chez EY m'a permis de développer mes compétences en Java et de travailler sur des projets réels. L'environnement est très professionnel et inspirant.</p>
                        <div class="star-rating">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center mb-3">
                            <div class="avatar-testimonial me-3">F</div>
                            <div>
                                <h6 class="mb-0 fw-bold">Fatima Zahra Khouni</h6>
                                <small class="text-muted">Data Scientist</small>
                            </div>
                        </div>
                        <p class="card-text text-muted mb-3">L'équipe m'a encadré de manière exceptionnelle. J'ai pu appliquer mes connaissances théoriques et apprendre des technologies modernes comme le machine learning.</p>
                        <div class="star-rating">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center mb-3">
                            <div class="avatar-testimonial me-3">M</div>
                            <div>
                                <h6 class="mb-0 fw-bold">Marwa Jaidane</h6>
                                <small class="text-muted">Développeuse Frontend</small>
                            </div>
                        </div>
                        <p class="card-text text-muted mb-3">Mon expérience a été enrichissante. Les projets étaient stimulants et j'ai pu créer des interfaces modernes avec React. Fortement recommandé !</p>
                        <div class="star-rating">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="py-5" style="background: linear-gradient(135deg, var(--ey-dark) 0%, #1a1a24 100%);">
    <div class="container text-center text-white">
        <h2 class="fw-bold mb-3">Prêt à lancer votre carrière ?</h2>
        <p class="lead mb-4 opacity-75">Rejoignez EY et développez vos compétences aux côtés d'experts reconnus.</p>
        <div class="d-flex justify-content-center gap-3 flex-wrap">
            <a href="inscription.php" class="btn btn-ey btn-lg">
                <i class="bi bi-person-plus me-2"></i> Créer mon compte
            </a>
            <a href="stages.php" class="btn btn-outline-light btn-lg">
                <i class="bi bi-briefcase me-2"></i> Parcourir les offres
            </a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
