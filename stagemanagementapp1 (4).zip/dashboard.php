<?php
require_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: connexion.php');
    exit;
}

// Rediriger vers le bon dashboard selon le rôle
$role = $_SESSION['role'];

switch ($role) {
    case 'admin':
        header('Location: dashboards/admin.php');
        break;
    case 'encadrant':
        header('Location: dashboards/encadrant.php');
        break;
    case 'stagiaire':
        header('Location: dashboards/stagiaire.php');
        break;
    default:
        header('Location: connexion.php');
        break;
}
exit;
?>
