<?php
require_once 'config/database.php';
include 'includes/header.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = htmlspecialchars(trim($_POST['nom'] ?? ''));
    $email = htmlspecialchars(trim($_POST['email'] ?? ''));
    $sujet = htmlspecialchars(trim($_POST['sujet'] ?? ''));
    $message_text = htmlspecialchars(trim($_POST['message'] ?? ''));

    if ($nom && $email && $sujet && $message_text) {
        $message = '<div class="alert alert-success alert-dismissible fade show" role="alert">
                        Merci pour votre message ! Nous vous recontacterons bientôt.
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>';
    }
}
?>

<!-- Hero Section -->
<section class="bg-dark text-white py-5">
    <div class="container">
        <h1 class="fw-bold mb-3">Nous Contacter</h1>
        <p class="lead opacity-75 mb-0">Posez vos questions, nous sommes à votre écoute</p>
    </div>
</section>

<div class="container py-5">
    <div class="row g-5">
        <!-- Contact Form -->
        <div class="col-lg-8">
            <?php echo $message; ?>
            <h2 class="fw-bold mb-4">Envoyer un message</h2>
            <form method="POST" class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Nom complet</label>
                    <input type="text" class="form-control form-control-lg" name="nom" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control form-control-lg" name="email" required>
                </div>
                <div class="col-12">
                    <label class="form-label">Sujet</label>
                    <input type="text" class="form-control form-control-lg" name="sujet" placeholder="Sujet de votre message" required>
                </div>
                <div class="col-12">
                    <label class="form-label">Message</label>
                    <textarea class="form-control form-control-lg" name="message" rows="5" placeholder="Votre message..." required></textarea>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-ey btn-lg">
                        <i class="bi bi-send me-2"></i> Envoyer le message
                    </button>
                </div>
            </form>
        </div>

        <!-- Contact Info -->
        <div class="col-lg-4">
            <h2 class="fw-bold mb-4">Informations</h2>
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="fw-bold text-warning mb-2"><i class="bi bi-geo-alt me-2"></i> Adresse</h6>
                    <p class="mb-0 text-muted small">
                        EY Tunisie<br>
                        Centre-Ville de Tunis<br>
                        1000 Tunis, Tunisie
                    </p>
                </div>
            </div>
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="fw-bold text-warning mb-2"><i class="bi bi-telephone me-2"></i> Téléphone</h6>
                    <p class="mb-0 text-muted small">+216 71 961 100</p>
                </div>
            </div>
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="fw-bold text-warning mb-2"><i class="bi bi-envelope me-2"></i> Email</h6>
                    <p class="mb-0 text-muted small">stages@ey.tn</p>
                </div>
            </div>
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h6 class="fw-bold text-warning mb-2"><i class="bi bi-clock me-2"></i> Horaires</h6>
                    <p class="mb-1 text-muted small">Lun - Jeu: 8h - 17h</p>
                    <p class="mb-0 text-muted small">Vendredi: 8h - 16h</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
