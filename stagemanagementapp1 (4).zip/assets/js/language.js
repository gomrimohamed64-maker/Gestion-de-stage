// Language translations
const translations = {
  fr: {
    home: "Accueil",
    stages: "Stages",
    about: "À propos",
    contact: "Contact",
    faq: "FAQ",
    search: "Rechercher...",
    sign_up: "S'inscrire",
    login: "Connexion",
    search_results: "Résultats de recherche",
    search_for: "Recherche pour:",
    no_results: "Aucun stage ne correspond à votre recherche.",
    view_all_stages: "Consulter tous les stages",
    see_details: "Voir les détails",
    available_places: "place(s) disponible(s)",
    duration: "Durée",
    location: "Lieu",
  },
  en: {
    home: "Home",
    stages: "Internships",
    about: "About",
    contact: "Contact",
    faq: "FAQ",
    search: "Search...",
    sign_up: "Sign Up",
    login: "Login",
    search_results: "Search Results",
    search_for: "Search for:",
    no_results: "No internships match your search.",
    view_all_stages: "View all internships",
    see_details: "View Details",
    available_places: "place(s) available",
    duration: "Duration",
    location: "Location",
  },
  ar: {
    home: "الصفحة الرئيسية",
    stages: "التدريب",
    about: "حول",
    contact: "اتصل",
    faq: "الأسئلة الشائعة",
    search: "بحث...",
    sign_up: "إنشاء حساب",
    login: "دخول",
    search_results: "نتائج البحث",
    search_for: "البحث عن:",
    no_results: "لا توجد برامج تدريب تطابق البحث الخاص بك.",
    view_all_stages: "عرض جميع برامج التدريب",
    see_details: "عرض التفاصيل",
    available_places: "مكان(ات) متاح(ة)",
    duration: "المدة",
    location: "الموقع",
  },
}

// Get current language or default to French
function getCurrentLanguage() {
  return localStorage.getItem("preferred_language") || "fr"
}

// Translate text
function getTranslation(key, lang = null) {
  lang = lang || getCurrentLanguage()
  return translations[lang] && translations[lang][key] ? translations[lang][key] : key
}

// Apply language to HTML elements with data-i18n attribute
function applyLanguage(language) {
  document.querySelectorAll("[data-i18n]").forEach((element) => {
    const key = element.getAttribute("data-i18n")
    element.textContent = getTranslation(key, language)
  })

  document.querySelectorAll("[data-i18n-placeholder]").forEach((element) => {
    const key = element.getAttribute("data-i18n-placeholder")
    element.placeholder = getTranslation(key, language)
  })

  // Set HTML lang attribute
  document.documentElement.lang = language
  if (language === "ar") {
    document.documentElement.dir = "rtl"
    document.body.style.direction = "rtl"
  } else {
    document.documentElement.dir = "ltr"
    document.body.style.direction = "ltr"
  }
}

// Initialize language on page load
document.addEventListener("DOMContentLoaded", () => {
  const savedLanguage = localStorage.getItem("preferred_language") || "fr"
  applyLanguage(savedLanguage)
})
