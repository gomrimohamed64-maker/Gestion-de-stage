-- =============================================
-- BASE DE DONNÉES GESTION DE STAGES EY
-- =============================================
-- Instructions: Importer ce fichier dans phpMyAdmin
-- =============================================

DROP DATABASE IF EXISTS gestion_stage;
CREATE DATABASE gestion_stage CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestion_stage;

-- =============================================
-- TABLE DES UTILISATEURS
-- =============================================
CREATE TABLE utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(255) NOT NULL,
    telephone VARCHAR(20),
    adresse TEXT,
    photo VARCHAR(255) DEFAULT NULL,
    role ENUM('stagiaire', 'admin', 'encadrant') NOT NULL DEFAULT 'stagiaire',
    specialite VARCHAR(100) DEFAULT NULL,
    date_inscription DATETIME DEFAULT CURRENT_TIMESTAMP,
    statut ENUM('actif', 'inactif') DEFAULT 'actif'
) ENGINE=InnoDB;

-- =============================================
-- TABLE DES STAGES
-- =============================================
CREATE TABLE stages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(200) NOT NULL,
    description TEXT,
    departement VARCHAR(100),
    duree VARCHAR(50),
    date_debut DATE,
    date_fin DATE,
    competences_requises TEXT,
    remuneration VARCHAR(100) DEFAULT 'À négocier',
    lieu VARCHAR(100) DEFAULT 'Tunis',
    places_disponibles INT DEFAULT 1,
    statut ENUM('ouvert', 'ferme') DEFAULT 'ouvert',
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =============================================
-- TABLE DES CANDIDATURES
-- =============================================
CREATE TABLE candidatures (
    id INT AUTO_INCREMENT PRIMARY KEY,
    stagiaire_id INT NOT NULL,
    stage_id INT NOT NULL,
    lettre_motivation TEXT,
    cv_path VARCHAR(255),
    statut ENUM('en_attente', 'acceptee', 'refusee') DEFAULT 'en_attente',
    date_candidature DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (stagiaire_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (stage_id) REFERENCES stages(id) ON DELETE CASCADE,
    UNIQUE KEY unique_candidature (stagiaire_id, stage_id)
) ENGINE=InnoDB;

-- =============================================
-- TABLE DES AFFECTATIONS
-- =============================================
CREATE TABLE affectations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    encadrant_id INT NOT NULL,
    stagiaire_id INT NOT NULL,
    stage_id INT NOT NULL,
    date_debut DATE,
    date_fin DATE,
    date_affectation DATETIME DEFAULT CURRENT_TIMESTAMP,
    statut ENUM('en_cours', 'termine') DEFAULT 'en_cours',
    FOREIGN KEY (encadrant_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (stagiaire_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (stage_id) REFERENCES stages(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =============================================
-- TABLE DES ÉVALUATIONS
-- =============================================
CREATE TABLE evaluations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    affectation_id INT NOT NULL,
    note INT CHECK (note >= 0 AND note <= 20),
    commentaire TEXT,
    competences_acquises TEXT,
    points_amelioration TEXT,
    date_evaluation DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (affectation_id) REFERENCES affectations(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =============================================
-- TABLE DES NOTIFICATIONS
-- =============================================
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL,
    titre VARCHAR(200) NOT NULL,
    message TEXT,
    lu BOOLEAN DEFAULT FALSE,
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Added project management table for task tracking
-- =============================================
-- TABLE DES TÂCHES PROJET
-- =============================================
CREATE TABLE taches_projet (
    id INT AUTO_INCREMENT PRIMARY KEY,
    affectation_id INT NOT NULL,
    titre VARCHAR(255) NOT NULL,
    description TEXT,
    date_limite DATE NOT NULL,
    priorite ENUM('basse', 'moyenne', 'haute') DEFAULT 'moyenne',
    statut ENUM('a_faire', 'en_cours', 'terminees') DEFAULT 'a_faire',
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_modification TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (affectation_id) REFERENCES affectations(id) ON DELETE CASCADE,
    INDEX idx_affectation_id (affectation_id),
    INDEX idx_statut (statut)
) ENGINE=InnoDB;

-- =============================================
-- INSERTION DES DONNÉES DE TEST
-- =============================================

-- Admin (mot de passe: password)
INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, telephone) VALUES 
('Admin', 'EY', 'admin@ey.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', '0522123456');

-- Encadrants (mot de passe: password)
INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, telephone, specialite) VALUES 
('Ben Ahmed', 'Karim', 'karim.benachmed@ey.tn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'encadrant', '0698123456', 'Développement Backend'),
('Khalil', 'Amira', 'amira.khalil@ey.tn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'encadrant', '0687654321', 'Développement Frontend'),
('Mansour', 'Nadia', 'nadia.mansour@ey.tn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'encadrant', '0675432109', 'DevOps & Infrastructure');

-- Stagiaires de test (mot de passe: password)
INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, telephone) VALUES 
('Saidi', 'Mohamed', 'mohamed.saidi@email.tn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'stagiaire', '0645678901'),
('Bouazizi', 'Leila', 'leila.bouazizi@email.tn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'stagiaire', '0656789012');

-- Stages en Informatique en Tunisie
INSERT INTO stages (titre, description, departement, duree, date_debut, date_fin, competences_requises, remuneration, lieu, places_disponibles) VALUES
('Stage Développement Backend Java', 'Rejoignez notre équipe de développement backend pour participer au développement d''applications web robustes et scalables avec Java Spring Boot. Vous travaillerez sur l''architecture microservices, les APIs RESTful et les bases de données PostgreSQL.', 'Développement Backend', '5 mois', '2026-02-01', '2026-07-01', 'Java, Spring Boot, REST API, PostgreSQL, Git, Linux', '800 TND/mois', 'Tunis', 3),
('Stage Développement Frontend React', 'Intégrez notre équipe frontend pour créer des interfaces utilisateur modernes et responsives avec React.js. Travail sur les composants réutilisables, gestion d''état avec Redux, et intégration d''APIs.', 'Développement Frontend', '5 mois', '2026-02-15', '2026-07-15', 'React.js, JavaScript ES6+, CSS3, API REST, Git, Responsive Design', '800 TND/mois', 'Tunis', 3),
('Stage Data Science et IA', 'Participez à nos projets de Data Science et Machine Learning. Analyse de données massives, création de modèles prédictifs, et visualisation de données avec Python, Pandas, Scikit-learn et TensorFlow.', 'Data Science', '6 mois', '2026-03-01', '2026-09-01', 'Python, Machine Learning, Pandas, Scikit-learn, TensorFlow, SQL, Jupyter', '900 TND/mois', 'Sousse', 2),
('Stage DevOps et Cloud', 'Rejoignez notre équipe DevOps pour gérer l''infrastructure cloud (AWS, Azure), l''automatisation des déploiements avec Docker et Kubernetes, et la surveillance des applications.', 'DevOps & Infrastructure', '5 mois', '2026-02-01', '2026-07-01', 'Docker, Kubernetes, AWS/Azure, CI/CD, Linux, Ansible, Terraform', '900 TND/mois', 'Ariana', 2),
('Stage Cybersécurité', 'Intégrez notre équipe de sécurité informatique pour assurer la protection des données et des systèmes. Audit de sécurité, test de pénétration, gestion des vulnérabilités et conformité RGPD.', 'Cybersécurité', '6 mois', '2026-03-15', '2026-09-15', 'Sécurité réseau, Ethical Hacking, RGPD, Linux, Penetration Testing, Firewall', '950 TND/mois', 'Tunis', 2),
('Stage Full Stack Development', 'Devenez développeur full stack en participant à tous les aspects du développement: frontend Angular, backend Node.js/Express, bases de données MongoDB et déploiement sur cloud.', 'Développement Full Stack', '6 mois', '2026-04-01', '2026-10-01', 'Angular, Node.js, Express, MongoDB, JavaScript, REST API, Docker', '850 TND/mois', 'Tunis', 2),
('Stage Mobile App Development', 'Créez des applications mobiles innovantes avec React Native ou Flutter. Participez à l''intégralité du cycle de développement: design, développement, test et déploiement sur App Store et Google Play.', 'Développement Mobile', '5 mois', '2026-02-01', '2026-07-01', 'React Native/Flutter, JavaScript/Dart, API REST, Firebase, Git', '850 TND/mois', 'Sfax', 2);

-- Candidatures de test
INSERT INTO candidatures (stagiaire_id, stage_id, lettre_motivation, statut) VALUES
(5, 1, 'Étudiant en informatique spécialisé en développement backend, je souhaite approfondir mes compétences en Java et Spring Boot dans votre entreprise...', 'en_attente'),
(6, 2, 'Passionnée par le développement frontend et l''expérience utilisateur, je suis motivée pour contribuer à vos projets React...', 'en_attente');

-- =============================================
-- FIN DU SCRIPT
-- =============================================
