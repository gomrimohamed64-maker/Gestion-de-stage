<?php
require_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pdo = getConnection();
$stage_id = $_GET['id'] ?? 0;

// Récupérer le stage
$stmt = $pdo->prepare("SELECT * FROM stages WHERE id = ?");
$stmt->execute([$stage_id]);
$stage = $stmt->fetch();

if (!$stage) {
    header('Location: stages.php');
    exit;
}

// Vérifier si l'utilisateur a déjà postulé
$deja_postule = false;
if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'stagiaire') {
    $stmt = $pdo->prepare("SELECT id FROM candidatures WHERE stagiaire_id = ? AND stage_id = ?");
    $stmt->execute([$_SESSION['user_id'], $stage_id]);
    $deja_postule = $stmt->fetch() !== false;
}

// Traitement de la candidature
$message = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id']) && $_SESSION['role'] === 'stagiaire') {
    $lettre = $_POST['lettre_motivation'] ?? '';
    
    if (empty($lettre)) {
        $error = "Veuillez rédiger une lettre de motivation.";
    } else {
        // Gestion du CV
        $cv_path = null;
        if (isset($_FILES['cv']) && $_FILES['cv']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/cv/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_ext = strtolower(pathinfo($_FILES['cv']['name'], PATHINFO_EXTENSION));
            $allowed_ext = ['pdf', 'doc', 'docx'];
            
            if (in_array($file_ext, $allowed_ext)) {
                $new_filename = 'cv_' . $_SESSION['user_id'] . '_' . time() . '.' . $file_ext;
                $cv_path = $upload_dir . $new_filename;
                move_uploaded_file($_FILES['cv']['tmp_name'], $cv_path);
            } else {
                $error = "Format de CV non autorisé. Utilisez PDF, DOC ou DOCX.";
            }
        }
        
        if (empty($error)) {
            $stmt = $pdo->prepare("INSERT INTO candidatures (stagiaire_id, stage_id, lettre_motivation, cv_path) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$_SESSION['user_id'], $stage_id, $lettre, $cv_path])) {
                $message = "Votre candidature a été envoyée avec succès!";
                $deja_postule = true;
            } else {
                $error = "Erreur lors de l'envoi de la candidature.";
            }
        }
    }
}

include 'includes/header.php';
?>

<div class="container py-5">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
            <li class="breadcrumb-item"><a href="stages.php">Stages</a></li>
            <li class="breadcrumb-item active"><?= htmlspecialchars($stage['titre']) ?></li>
        </ol>
    </nav>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <span class="badge bg-dark fs-6"><?= htmlspecialchars($stage['departement']) ?></span>
                        <span class="badge bg-<?= $stage['statut'] === 'ouvert' ? 'success' : 'danger' ?> fs-6">
                            <?= ucfirst($stage['statut']) ?>
                        </span>
                    </div>
                    
                    <h1 class="mb-4"><?= htmlspecialchars($stage['titre']) ?></h1>
                    
                    <h5><i class="bi bi-file-text"></i> Description</h5>
                    <p class="text-muted"><?= nl2br(htmlspecialchars($stage['description'])) ?></p>
                    
                    <h5 class="mt-4"><i class="bi bi-tools"></i> Compétences requises</h5>
                    <p>
                        <?php foreach (explode(',', $stage['competences_requises']) as $comp): ?>
                        <span class="badge bg-light text-dark me-1 mb-1"><?= trim($comp) ?></span>
                        <?php endforeach; ?>
                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <!-- Informations -->
            <div class="card mb-4">
                <div class="card-header bg-dark text-white">
                    <i class="bi bi-info-circle"></i> Informations
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between">
                        <span><i class="bi bi-clock text-primary"></i> Durée</span>
                        <strong><?= htmlspecialchars($stage['duree']) ?></strong>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span><i class="bi bi-calendar-event text-success"></i> Début</span>
                        <strong><?= date('d/m/Y', strtotime($stage['date_debut'])) ?></strong>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span><i class="bi bi-calendar-check text-danger"></i> Fin</span>
                        <strong><?= date('d/m/Y', strtotime($stage['date_fin'])) ?></strong>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span><i class="bi bi-people text-warning"></i> Places</span>
                        <strong><?= $stage['places_disponibles'] ?></strong>
                    </li>
                </ul>
            </div>
            
            <!-- Candidature -->
            <div class="card">
                <div class="card-header bg-warning">
                    <i class="bi bi-send"></i> Postuler à ce stage
                </div>
                <div class="card-body">
                    <?php if ($message): ?>
                        <div class="alert alert-success">
                            <i class="bi bi-check-circle"></i> <?= $message ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger">
                            <i class="bi bi-exclamation-circle"></i> <?= $error ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!isset($_SESSION['user_id'])): ?>
                        <!-- Message pour utilisateur non connecté -->
                        <div class="text-center py-3">
                            <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                                <i class="bi bi-lock fs-1 text-secondary"></i>
                            </div>
                            <h5>Connexion requise</h5>
                            <p class="text-muted mb-4">Pour postuler à ce stage avec votre CV et lettre de motivation, vous devez d'abord vous connecter ou créer un compte.</p>
                            <div class="d-grid gap-2">
                                <a href="connexion.php?redirect=stage-detail.php?id=<?= $stage_id ?>" class="btn btn-ey btn-lg">
                                    <i class="bi bi-box-arrow-in-right"></i> Se connecter
                                </a>
                                <a href="inscription.php" class="btn btn-outline-dark">
                                    <i class="bi bi-person-plus"></i> Créer un compte
                                </a>
                            </div>
                        </div>
                        
                    <?php elseif ($_SESSION['role'] !== 'stagiaire'): ?>
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-info-circle"></i> Seuls les stagiaires peuvent postuler aux offres de stage.
                        </div>
                        
                    <?php elseif ($deja_postule): ?>
                        <div class="alert alert-success mb-0">
                            <i class="bi bi-check-circle"></i> <strong>Candidature envoyée!</strong><br>
                            Vous avez déjà postulé à ce stage. Suivez l'état de votre candidature dans votre <a href="dashboard.php">espace personnel</a>.
                        </div>
                        
                    <?php elseif ($stage['statut'] !== 'ouvert'): ?>
                        <div class="alert alert-warning mb-0">
                            <i class="bi bi-exclamation-triangle"></i> Ce stage n'est plus disponible aux candidatures.
                        </div>
                        
                    <?php else: ?>
                        <!-- Formulaire de candidature avec CV et lettre -->
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="bi bi-file-earmark-pdf"></i> Votre CV <span class="text-muted">(optionnel)</span>
                                </label>
                                <input type="file" name="cv" class="form-control" accept=".pdf,.doc,.docx">
                                <small class="text-muted">Formats acceptés: PDF, DOC, DOCX (max 5MB)</small>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="bi bi-envelope-paper"></i> Lettre de motivation <span class="text-danger">*</span>
                                </label>
                                <textarea name="lettre_motivation" class="form-control" rows="6" required placeholder="Expliquez pourquoi vous souhaitez effectuer ce stage chez EY...

- Vos motivations
- Vos compétences pertinentes
- Ce que vous espérez apprendre"></textarea>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-ey btn-lg">
                                    <i class="bi bi-send"></i> Envoyer ma candidature
                                </button>
                            </div>
                            
                            <p class="text-muted small mt-3 mb-0 text-center">
                                <i class="bi bi-shield-check"></i> Vos informations sont traitées de manière confidentielle
                            </p>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
