<?php
require_once 'config/database.php';
include 'includes/header.php';
?>

<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h1 class="fw-bold mb-3">Centre d'aide</h1>
            <p class="lead text-muted">Trouvez des réponses à vos questions et obtenez du support</p>
        </div>

        <div class="row g-4 mb-5">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div style="font-size: 2rem; color: #ffe600; margin-bottom: 15px;">
                            <i class="bi bi-question-circle"></i>
                        </div>
                        <h5 class="card-title fw-bold mb-3">Questions Fréquentes</h5>
                        <p class="text-muted mb-3">Consultez notre FAQ complète pour les questions les plus courantes.</p>
                        <a href="faq.php" class="btn btn-ey">
                            <i class="bi bi-arrow-right"></i> Aller à la FAQ
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div style="font-size: 2rem; color: #ffe600; margin-bottom: 15px;">
                            <i class="bi bi-envelope"></i>
                        </div>
                        <h5 class="card-title fw-bold mb-3">Nous Contacter</h5>
                        <p class="text-muted mb-3">Envoyez-nous un message et nous répondrons dans les 24 heures.</p>
                        <a href="contact.php" class="btn btn-ey">
                            <i class="bi bi-arrow-right"></i> Formulaire de contact
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-md-3">
                <div class="card text-center border-0 shadow-sm">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; color: #ffe600; margin-bottom: 10px;">
                            <i class="bi bi-calendar-check"></i>
                        </div>
                        <h6 class="fw-bold mb-2">Guide du Candidat</h6>
                        <p class="small text-muted mb-0">Comment candidater et préparer votre stage</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card text-center border-0 shadow-sm">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; color: #ffe600; margin-bottom: 10px;">
                            <i class="bi bi-person-badge"></i>
                        </div>
                        <h6 class="fw-bold mb-2">Espace Encadrant</h6>
                        <p class="small text-muted mb-0">Guide pour gérer vos stagiaires</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card text-center border-0 shadow-sm">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; color: #ffe600; margin-bottom: 10px;">
                            <i class="bi bi-gear"></i>
                        </div>
                        <h6 class="fw-bold mb-2">Aide Technique</h6>
                        <p class="small text-muted mb-0">Problèmes de connexion ou accès</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card text-center border-0 shadow-sm">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; color: #ffe600; margin-bottom: 10px;">
                            <i class="bi bi-telephone"></i>
                        </div>
                        <h6 class="fw-bold mb-2">Contact Direct</h6>
                        <p class="small text-muted mb-0">Appelez-nous directement</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contact Info Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="text-center">
                    <div style="font-size: 2rem; color: #2e2e38; margin-bottom: 15px;">
                        <i class="bi bi-telephone"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Téléphone</h5>
                    <p class="text-muted">+216 71 961 100</p>
                    <p class="small text-muted">Lun - Jeu: 8h - 17h</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <div style="font-size: 2rem; color: #2e2e38; margin-bottom: 15px;">
                        <i class="bi bi-envelope"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Email</h5>
                    <p class="text-muted"><a href="mailto:stages@ey.tn" class="text-decoration-none text-muted">stages@ey.tn</a></p>
                    <p class="small text-muted">Réponse en 24 heures</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <div style="font-size: 2rem; color: #2e2e38; margin-bottom: 15px;">
                        <i class="bi bi-geo-alt"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Adresse</h5>
                    <p class="text-muted">Centre-Ville de Tunis</p>
                    <p class="small text-muted">1000 Tunis, Tunisie</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
