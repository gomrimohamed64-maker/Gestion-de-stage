<?php
require_once 'config/database.php';
include 'includes/header.php';

$pdo = getConnection();

// Filtres
$departement = $_GET['departement'] ?? '';
$search = $_GET['search'] ?? '';

$sql = "SELECT * FROM stages WHERE statut = 'ouvert'";
$params = [];

if ($departement) {
    $sql .= " AND departement = ?";
    $params[] = $departement;
}

if ($search) {
    $sql .= " AND (titre LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$sql .= " ORDER BY date_creation DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$stages = $stmt->fetchAll();

// Départements pour le filtre
$depts = $pdo->query("SELECT DISTINCT departement FROM stages")->fetchAll(PDO::FETCH_COLUMN);

// Compteur
$total_stages = count($stages);
?>

<!-- Hero Banner -->
<section class="bg-dark text-white py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <span class="badge bg-warning text-dark mb-3 px-3 py-2">
                    <i class="bi bi-briefcase-fill me-1"></i> Opportunités
                </span>
                <h1 class="fw-bold mb-3">Trouvez votre stage idéal</h1>
                <p class="lead opacity-75 mb-0">Découvrez nos <?= $total_stages ?> offres de stage et lancez votre carrière chez EY.</p>
            </div>
            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                <div class="d-inline-block text-center">
                    <span class="display-4 fw-bold text-warning"><?= $total_stages ?></span>
                    <p class="mb-0 opacity-75">Stages disponibles</p>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="container py-5">
    <!-- Filtres -->
    <div class="card mb-4 border-0 shadow-sm">
        <div class="card-body p-4">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-lg-5 col-md-12">
                    <label class="form-label small text-muted fw-bold">
                        <i class="bi bi-search me-1"></i> RECHERCHER
                    </label>
                    <input type="text" name="search" class="form-control form-control-lg" placeholder="Titre, description, compétences..." value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-lg-4 col-md-6">
                    <label class="form-label small text-muted fw-bold">
                        <i class="bi bi-building me-1"></i> DÉPARTEMENT
                    </label>
                    <select name="departement" class="form-select form-select-lg">
                        <option value="">Tous les départements</option>
                        <?php foreach ($depts as $dept): ?>
                        <option value="<?= htmlspecialchars($dept) ?>" <?= $departement === $dept ? 'selected' : '' ?>><?= htmlspecialchars($dept) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-ey btn-lg">
                            <i class="bi bi-funnel me-2"></i> Filtrer
                        </button>
                    </div>
                </div>
            </form>
            <?php if ($search || $departement): ?>
            <div class="mt-3 pt-3 border-top">
                <span class="text-muted">Filtres actifs:</span>
                <?php if ($search): ?>
                <span class="badge bg-dark ms-2">"<?= htmlspecialchars($search) ?>" <a href="?departement=<?= urlencode($departement) ?>" class="text-white ms-1">&times;</a></span>
                <?php endif; ?>
                <?php if ($departement): ?>
                <span class="badge bg-secondary ms-2"><?= htmlspecialchars($departement) ?> <a href="?search=<?= urlencode($search) ?>" class="text-white ms-1">&times;</a></span>
                <?php endif; ?>
                <a href="stages.php" class="btn btn-sm btn-outline-secondary ms-2">Effacer tout</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Résultats -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <p class="text-muted mb-0">
            <strong><?= $total_stages ?></strong> stage(s) trouvé(s)
        </p>
        <div class="btn-group" role="group">
            <button type="button" class="btn btn-outline-secondary active">
                <i class="bi bi-grid-3x2-gap"></i>
            </button>
            <button type="button" class="btn btn-outline-secondary">
                <i class="bi bi-list"></i>
            </button>
        </div>
    </div>
    
    <!-- Liste des stages -->
    <div class="row g-4">
        <?php if (empty($stages)): ?>
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center py-5">
                    <i class="bi bi-search fs-1 text-muted mb-3"></i>
                    <h4>Aucun stage trouvé</h4>
                    <p class="text-muted mb-4">Essayez de modifier vos critères de recherche.</p>
                    <a href="stages.php" class="btn btn-ey">
                        <i class="bi bi-arrow-left me-2"></i> Voir tous les stages
                    </a>
                </div>
            </div>
        </div>
        <?php else: ?>
            <?php foreach ($stages as $stage): ?>
            <div class="col-lg-6">
                <div class="card card-stage h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <span class="badge bg-dark px-3 py-2"><?= htmlspecialchars($stage['departement']) ?></span>
                            <div class="text-end">
                                <span class="badge bg-success px-3 py-2">
                                    <i class="bi bi-people me-1"></i> <?= $stage['places_disponibles'] ?> place(s)
                                </span>
                            </div>
                        </div>
                        
                        <h5 class="card-title fw-bold mb-3"><?= htmlspecialchars($stage['titre']) ?></h5>
                        <p class="card-text text-muted"><?= substr(htmlspecialchars($stage['description']), 0, 150) ?>...</p>
                        
                        <div class="row g-2 mb-3">
                            <div class="col-6">
                                <div class="bg-light rounded p-2 text-center">
                                    <i class="bi bi-clock text-warning"></i>
                                    <small class="d-block text-muted">Durée</small>
                                    <strong class="small"><?= htmlspecialchars($stage['duree']) ?></strong>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="bg-light rounded p-2 text-center">
                                    <i class="bi bi-geo-alt text-warning"></i>
                                    <small class="d-block text-muted">Lieu</small>
                                    <strong class="small"><?= htmlspecialchars($stage['lieu'] ?? 'Casablanca') ?></strong>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <small class="text-muted d-block mb-2">
                                <i class="bi bi-calendar-range me-1"></i>
                                <?= date('d/m/Y', strtotime($stage['date_debut'])) ?> - <?= date('d/m/Y', strtotime($stage['date_fin'])) ?>
                            </small>
                            <div class="d-flex flex-wrap gap-1">
                                <?php 
                                $competences = explode(',', $stage['competences_requises']);
                                foreach (array_slice($competences, 0, 3) as $comp): 
                                ?>
                                <span class="badge bg-light text-dark border"><?= trim($comp) ?></span>
                                <?php endforeach; ?>
                                <?php if (count($competences) > 3): ?>
                                <span class="badge bg-light text-muted border">+<?= count($competences) - 3 ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer bg-white border-0 p-4 pt-0">
                        <a href="stage-detail.php?id=<?= $stage['id'] ?>" class="btn btn-ey w-100">
                            <i class="bi bi-arrow-right me-2"></i> Voir les détails et postuler
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
