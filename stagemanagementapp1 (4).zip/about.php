<?php
require_once 'config/database.php';
include 'includes/header.php';
?>

<!-- Hero Section -->
<section class="bg-dark text-white py-5">
    <div class="container">
        <h1 class="fw-bold mb-3">À propos d'EY</h1>
        <p class="lead opacity-75 mb-0">Découvrez qui nous sommes et notre impact dans le monde</p>
    </div>
</section>

<div class="container py-5">
    <!-- Company Overview -->
    <section class="mb-5">
        <div class="row align-items-center g-4">
            <div class="col-lg-6">
                <span class="badge bg-warning text-dark mb-3 px-3 py-2">Notre histoire</span>
                <h2 class="fw-bold mb-4">EY - Building a better working world</h2>
                <p class="mb-3">EY est un leader mondial dont la mission est de "Building a better working world". Nous contribuons à la création d'une valeur à long terme pour nos clients, nos collaborateurs et la société, et nous facilitons la confiance dans les marchés et les économies dans le monde.</p>
                <p class="mb-3">Depuis 1989 en Tunisie, nous nous engageons à offrir les meilleurs services d'audit, de conseil fiscal et de transactions avec l'expertise et l'innovation en tant que piliers.</p>
                <div class="row g-3 mt-4">
                    <div class="col-sm-6">
                        <div class="p-3 bg-light rounded">
                            <div class="h5 text-warning fw-bold">150+</div>
                            <p class="mb-0 small">Pays à travers le monde</p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="p-3 bg-light rounded">
                            <div class="h5 text-warning fw-bold">300K+</div>
                            <p class="mb-0 small">Collaborateurs passionnés</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card border-0 shadow-lg">
                    <div class="card-body p-5 text-center">
                        <i class="bi bi-briefcase" style="font-size: 4rem; color: #ffe600;"></i>
                        <h4 class="mt-3 fw-bold">Expertise Diversifiée</h4>
                        <p class="text-muted">Audit, Consulting, Tax & Law, Strategy and Transactions</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Values Section -->
    <section class="py-5 border-top">
        <h2 class="fw-bold mb-5 text-center">Nos Valeurs</h2>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="text-center p-4">
                    <i class="bi bi-star-fill" style="font-size: 3rem; color: #ffe600;"></i>
                    <h5 class="fw-bold mt-3 mb-2">Excellence</h5>
                    <p class="text-muted mb-0">Nous nous efforçons d'atteindre les plus hauts standards de qualité dans tout ce que nous faisons.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center p-4">
                    <i class="bi bi-heart-fill" style="font-size: 3rem; color: #ffe600;"></i>
                    <h5 class="fw-bold mt-3 mb-2">Intégrité</h5>
                    <p class="text-muted mb-0">L'honnêteté et la transparence sont au cœur de nos relations avec tous nos partenaires.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center p-4">
                    <i class="bi bi-people-fill" style="font-size: 3rem; color: #ffe600;"></i>
                    <h5 class="fw-bold mt-3 mb-2">Collaboration</h5>
                    <p class="text-muted mb-0">Ensemble, nous créons des solutions innovantes qui transforment les organisations.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section class="py-5 border-top">
        <h2 class="fw-bold mb-5 text-center">Notre Engagement envers les Talents</h2>
        <div class="row g-4">
            <div class="col-lg-6">
                <h5 class="fw-bold mb-3">Formation et Développement</h5>
                <p class="mb-3">Nous offrons des programmes de formation complets et un mentorat personnalisé pour aider nos collaborateurs à développer leurs compétences et à avancer dans leurs carrières.</p>
                <ul class="list-unstyled">
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Programmes de certification professionnels</li>
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Mentorat personnalisé</li>
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Opportunités de développement international</li>
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Environnement de travail inclusif</li>
                </ul>
            </div>
            <div class="col-lg-6">
                <h5 class="fw-bold mb-3">Avantages et Bénéfices</h5>
                <p class="mb-3">Nous nous engageons à créer un environnement de travail favorable qui reconnaît et récompense l'excellence.</p>
                <ul class="list-unstyled">
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Rémunération compétitive</li>
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Assurance maladie complète</li>
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Horaires flexibles et télétravail</li>
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Environnement diversifié et inclusif</li>
                </ul>
            </div>
        </div>
    </section>
</div>

<?php include 'includes/footer.php'; ?>
