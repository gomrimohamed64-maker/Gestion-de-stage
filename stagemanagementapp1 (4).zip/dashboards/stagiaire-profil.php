<?php
require_once dirname(__FILE__) . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'stagiaire') {
    header('Location: ../connexion.php');
    exit;
}

$pdo = getConnection();
$user_id = $_SESSION['user_id'];

$success_msg = '';
$error_msg = '';

// Récupérer les infos du stagiaire
$user_stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$user_stmt->execute([$user_id]);
$user_info = $user_stmt->fetch();

// Traitement de la mise à jour du profil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom = trim($_POST['prenom'] ?? '');
    $nom = trim($_POST['nom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    
    if (empty($prenom) || empty($nom) || empty($email)) {
        $error_msg = "Veuillez remplir tous les champs obligatoires.";
    } else {
        $stmt = $pdo->prepare("UPDATE utilisateurs SET prenom = ?, nom = ?, email = ?, telephone = ? WHERE id = ?");
        if ($stmt->execute([$prenom, $nom, $email, $telephone, $user_id])) {
            $_SESSION['prenom'] = $prenom;
            $_SESSION['nom'] = $nom;
            $_SESSION['email'] = $email;
            $user_info['prenom'] = $prenom;
            $user_info['nom'] = $nom;
            $user_info['email'] = $email;
            $user_info['telephone'] = $telephone;
            $success_msg = "Profil mis à jour avec succès!";
        } else {
            $error_msg = "Erreur lors de la mise à jour du profil.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Profil - EY</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ey-yellow: #ffe600;
            --ey-dark: #2e2e38;
            --ey-gray: #747480;
            --ey-light: #f6f6fa;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--ey-light);
        }
        .sidebar {
            background: linear-gradient(180deg, var(--ey-dark) 0%, #1a1a24 100%);
            min-height: 100vh;
            position: fixed;
            width: 260px;
            padding: 20px;
            z-index: 1000;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 5px;
            transition: all 0.3s;
            text-decoration: none;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,230,0,0.15);
        }
        .sidebar .nav-link.active {
            border-left: 3px solid var(--ey-yellow);
        }
        .main-content {
            margin-left: 260px;
            padding: 30px;
        }
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .card-header {
            background: white;
            border-bottom: 1px solid #eee;
            font-weight: 600;
        }
        .btn-ey {
            background: var(--ey-yellow);
            color: var(--ey-dark);
            font-weight: 600;
            border: none;
        }
        .btn-ey:hover {
            background: #e6cf00;
            color: var(--ey-dark);
        }
        .ey-logo {
            background: var(--ey-yellow);
            color: var(--ey-dark);
            padding: 5px 12px;
            font-weight: 700;
            font-size: 1.5rem;
        }
        .avatar {
            width: 100px;
            height: 100px;
            background: var(--ey-yellow);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: var(--ey-dark);
            font-size: 2rem;
        }
        .form-control:focus {
            border-color: var(--ey-yellow);
            box-shadow: 0 0 0 0.2rem rgba(255, 230, 0, 0.25);
        }
        @media (max-width: 768px) {
            .sidebar { display: none; }
            .main-content { margin-left: 0; }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="text-center mb-4">
            <span class="ey-logo">EY</span>
            <p class="text-white mt-3 mb-1">Espace Stagiaire</p>
            <small class="text-white-50"><?php echo htmlspecialchars($user_info['prenom'] . ' ' . $user_info['nom']); ?></small>
        </div>
        <hr class="bg-secondary">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="stagiaire.php">
                    <i class="bi bi-house me-2"></i> Tableau de bord
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="stagiaire-candidatures.php">
                    <i class="bi bi-file-earmark-text me-2"></i> Mes candidatures
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../stages.php">
                    <i class="bi bi-briefcase me-2"></i> Offres de stage
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="stagiaire-profil.php">
                    <i class="bi bi-person me-2"></i> Mon profil
                </a>
            </li>
        </ul>
        <hr class="bg-secondary mt-4">
        <a href="../index.php" class="btn btn-outline-light btn-sm w-100 mb-2">
            <i class="bi bi-arrow-left"></i> Retour au site
        </a>
        <a href="../logout.php" class="btn btn-danger btn-sm w-100">
            <i class="bi bi-box-arrow-right"></i> Déconnexion
        </a>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Mon Profil</h2>
                <p class="text-muted mb-0">Gérez vos informations personnelles</p>
            </div>
            <div class="d-flex align-items-center">
                <span class="text-muted me-3"><i class="bi bi-calendar"></i> <?php echo date('d/m/Y'); ?></span>
                <div class="avatar"><?php echo strtoupper(substr($user_info['prenom'], 0, 1) . substr($user_info['nom'], 0, 1)); ?></div>
            </div>
        </div>

        <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle me-2"></i> <?php echo $success_msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($error_msg): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-circle me-2"></i> <?php echo $error_msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Profil Card -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-person-circle me-2"></i> Informations personnelles
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">
                                <i class="bi bi-person me-1"></i> Prénom *
                            </label>
                            <input type="text" name="prenom" class="form-control form-control-lg" value="<?php echo htmlspecialchars($user_info['prenom']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">
                                <i class="bi bi-person me-1"></i> Nom *
                            </label>
                            <input type="text" name="nom" class="form-control form-control-lg" value="<?php echo htmlspecialchars($user_info['nom']); ?>" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">
                                <i class="bi bi-envelope me-1"></i> Email *
                            </label>
                            <input type="email" name="email" class="form-control form-control-lg" value="<?php echo htmlspecialchars($user_info['email']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">
                                <i class="bi bi-telephone me-1"></i> Téléphone
                            </label>
                            <input type="tel" name="telephone" class="form-control form-control-lg" value="<?php echo htmlspecialchars($user_info['telephone'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div class="pt-3">
                        <button type="submit" class="btn btn-ey btn-lg">
                            <i class="bi bi-check-circle me-2"></i> Enregistrer les modifications
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
