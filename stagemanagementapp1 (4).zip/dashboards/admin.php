<?php
require_once dirname(__FILE__) . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../connexion.php');
    exit;
}

$pdo = getConnection();

// Traitement des actions
$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    
    try {
        // Ajouter un stage
        if ($action === 'add_stage') {
            $stmt = $pdo->prepare("INSERT INTO stages (titre, description, departement, duree, date_debut, date_fin, competences_requises, remuneration, lieu, places_disponibles) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $_POST['titre'], $_POST['description'], $_POST['departement'],
                $_POST['duree'], $_POST['date_debut'], $_POST['date_fin'],
                $_POST['competences'], $_POST['remuneration'], $_POST['lieu'], $_POST['places']
            ]);
            $success_msg = "Stage ajouté avec succès!";
        }
        
        // Supprimer un stage
        if ($action === 'delete_stage') {
            $stmt = $pdo->prepare("DELETE FROM stages WHERE id = ?");
            $stmt->execute([$_POST['stage_id']]);
            $success_msg = "Stage supprimé!";
        }
        
        // Modifier statut stage
        if ($action === 'toggle_stage') {
            $current = $_POST['current_status'];
            $new_status = ($current === 'ouvert') ? 'ferme' : 'ouvert';
            $stmt = $pdo->prepare("UPDATE stages SET statut = ? WHERE id = ?");
            $stmt->execute([$new_status, $_POST['stage_id']]);
            $success_msg = "Statut du stage modifié!";
        }
        
        // Valider/Refuser candidature
        if ($action === 'update_candidature') {
            $stmt = $pdo->prepare("UPDATE candidatures SET statut = ? WHERE id = ?");
            $stmt->execute([$_POST['statut'], $_POST['candidature_id']]);
            
            // Si accepté, créer une affectation
            if ($_POST['statut'] === 'acceptee' && !empty($_POST['encadrant_id'])) {
                $cand = $pdo->prepare("SELECT stagiaire_id, stage_id FROM candidatures WHERE id = ?");
                $cand->execute([$_POST['candidature_id']]);
                $c = $cand->fetch();
                
                // Récupérer les dates du stage
                $stage_dates = $pdo->prepare("SELECT date_debut, date_fin FROM stages WHERE id = ?");
                $stage_dates->execute([$c['stage_id']]);
                $dates = $stage_dates->fetch();
                
                $stmt = $pdo->prepare("INSERT INTO affectations (encadrant_id, stagiaire_id, stage_id, date_debut, date_fin) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$_POST['encadrant_id'], $c['stagiaire_id'], $c['stage_id'], $dates['date_debut'], $dates['date_fin']]);
            }
            $success_msg = "Candidature mise à jour!";
        }
        
        // Ajouter utilisateur
        if ($action === 'add_user') {
            $hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $specialite = isset($_POST['specialite']) ? $_POST['specialite'] : null;
            $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, telephone, role, specialite) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$_POST['nom'], $_POST['prenom'], $_POST['email'], $hash, $_POST['telephone'], $_POST['role'], $specialite]);
            $success_msg = "Utilisateur ajouté!";
        }
        
        // Supprimer utilisateur
        if ($action === 'delete_user') {
            $stmt = $pdo->prepare("DELETE FROM utilisateurs WHERE id = ? AND role != 'admin'");
            $stmt->execute([$_POST['user_id']]);
            $success_msg = "Utilisateur supprimé!";
        }
    } catch (PDOException $e) {
        $error_msg = "Erreur: " . $e->getMessage();
    }
}

// Statistiques
$stats = array(
    'stages' => $pdo->query("SELECT COUNT(*) FROM stages")->fetchColumn(),
    'stages_ouverts' => $pdo->query("SELECT COUNT(*) FROM stages WHERE statut = 'ouvert'")->fetchColumn(),
    'stagiaires' => $pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'stagiaire'")->fetchColumn(),
    'candidatures' => $pdo->query("SELECT COUNT(*) FROM candidatures WHERE statut = 'en_attente'")->fetchColumn(),
    'candidatures_total' => $pdo->query("SELECT COUNT(*) FROM candidatures")->fetchColumn(),
    'encadrants' => $pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'encadrant'")->fetchColumn(),
    'affectations' => $pdo->query("SELECT COUNT(*) FROM affectations")->fetchColumn(),
    'affectations_actives' => $pdo->query("SELECT COUNT(*) FROM affectations WHERE statut = 'en_cours'")->fetchColumn()
);

// Données
$candidatures = $pdo->query("
    SELECT c.*, u.nom, u.prenom, u.email, u.telephone, s.titre as stage_titre, s.departement,
           c.cv_path, c.lettre_motivation
    FROM candidatures c
    JOIN utilisateurs u ON c.stagiaire_id = u.id
    JOIN stages s ON c.stage_id = s.id
    ORDER BY c.date_candidature DESC
")->fetchAll();

$stages = $pdo->query("SELECT * FROM stages ORDER BY date_creation DESC")->fetchAll();
$encadrants = $pdo->query("SELECT * FROM utilisateurs WHERE role = 'encadrant'")->fetchAll();
$utilisateurs = $pdo->query("SELECT * FROM utilisateurs ORDER BY date_inscription DESC")->fetchAll();
$affectations = $pdo->query("
    SELECT a.*, s.titre as stage_titre, s.departement,
           st.nom as stagiaire_nom, st.prenom as stagiaire_prenom, st.email as stagiaire_email,
           en.nom as encadrant_nom, en.prenom as encadrant_prenom
    FROM affectations a
    JOIN stages s ON a.stage_id = s.id
    JOIN utilisateurs st ON a.stagiaire_id = st.id
    JOIN utilisateurs en ON a.encadrant_id = en.id
    ORDER BY a.date_affectation DESC
")->fetchAll();

// Taux d'acceptation
$accepted = $pdo->query("SELECT COUNT(*) FROM candidatures WHERE statut = 'acceptee'")->fetchColumn();
$taux_acceptation = ($stats['candidatures_total'] > 0) ? round(($accepted / $stats['candidatures_total']) * 100) : 0;

// Fonction pour obtenir le statut formaté
function getAdminStatusInfo($statut) {
    switch($statut) {
        case 'en_attente':
            return array('class' => 'status-en_attente', 'label' => 'En attente');
        case 'acceptee':
            return array('class' => 'status-acceptee', 'label' => 'Acceptée');
        case 'refusee':
            return array('class' => 'status-refusee', 'label' => 'Refusée');
        case 'ouvert':
            return array('class' => 'status-ouvert', 'label' => 'Ouvert');
        case 'ferme':
            return array('class' => 'status-ferme', 'label' => 'Fermé');
        default:
            return array('class' => 'bg-secondary', 'label' => $statut);
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration - EY Gestion Stages</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ey-yellow: #ffe600;
            --ey-dark: #2e2e38;
            --ey-gray: #747480;
            --ey-light: #f6f6fa;
        }
        body { font-family: 'Inter', sans-serif; background-color: var(--ey-light); }
        .sidebar {
            background: linear-gradient(180deg, var(--ey-dark) 0%, #1a1a24 100%);
            min-height: 100vh;
            position: fixed;
            width: 260px;
            padding: 20px;
            z-index: 1000;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 5px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,230,0,0.15);
        }
        .sidebar .nav-link.active { border-left: 3px solid var(--ey-yellow); }
        .sidebar .nav-link i { width: 20px; }
        .main-content { margin-left: 260px; padding: 30px; }
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s;
            height: 100%;
        }
        .stat-card:hover { transform: translateY(-3px); }
        .stat-card.primary { background: linear-gradient(135deg, var(--ey-dark), #3a3a48); color: white; }
        .stat-card.warning { background: linear-gradient(135deg, var(--ey-yellow), #e6cf00); color: var(--ey-dark); }
        .stat-card.success { background: linear-gradient(135deg, #28a745, #20c997); color: white; }
        .stat-card.danger { background: linear-gradient(135deg, #dc3545, #e74c3c); color: white; }
        .stat-card.info { background: linear-gradient(135deg, #17a2b8, #3498db); color: white; }
        .stat-number { font-size: 2rem; font-weight: 700; }
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .card-header { background: white; border-bottom: 1px solid #eee; font-weight: 600; }
        .btn-ey { background: var(--ey-yellow); color: var(--ey-dark); font-weight: 600; border: none; }
        .btn-ey:hover { background: #e6cf00; color: var(--ey-dark); }
        .ey-logo { background: var(--ey-yellow); color: var(--ey-dark); padding: 5px 12px; font-weight: 700; font-size: 1.5rem; }
        .table thead { background: var(--ey-dark); color: white; }
        .table thead th { font-weight: 500; border: none; }
        .avatar {
            width: 40px; height: 40px;
            background: var(--ey-yellow);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-weight: 600; color: var(--ey-dark); font-size: 0.9rem;
        }
        .status-badge { padding: 5px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: 500; }
        .status-en_attente { background: #fff3cd; color: #856404; }
        .status-acceptee { background: #d4edda; color: #155724; }
        .status-refusee { background: #f8d7da; color: #721c24; }
        .status-ouvert { background: #d4edda; color: #155724; }
        .status-ferme { background: #f8d7da; color: #721c24; }
        .nav-pills .nav-link { color: var(--ey-dark); border-radius: 8px; }
        .nav-pills .nav-link.active { background: var(--ey-dark); color: white; }
        .modal-header { background: var(--ey-dark); color: white; }
        .modal-header .btn-close { filter: invert(1); }
        .form-control:focus, .form-select:focus { border-color: var(--ey-yellow); box-shadow: 0 0 0 0.2rem rgba(255,230,0,0.25); }
        @media (max-width: 768px) { .sidebar { display: none; } .main-content { margin-left: 0; } }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="text-center mb-4">
            <span class="ey-logo">EY</span>
            <p class="text-white mt-3 mb-1">Administration</p>
            <small class="text-white-50"><?php echo htmlspecialchars($_SESSION['prenom'] . ' ' . $_SESSION['nom']); ?></small>
        </div>
        <hr class="bg-secondary">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="#dashboard" data-bs-toggle="pill">
                    <i class="bi bi-speedometer2 me-2"></i> Tableau de bord
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#stages" data-bs-toggle="pill">
                    <i class="bi bi-briefcase me-2"></i> Stages
                    <span class="badge bg-info float-end"><?php echo $stats['stages']; ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#candidatures" data-bs-toggle="pill">
                    <i class="bi bi-file-earmark-text me-2"></i> Candidatures
                    <?php if ($stats['candidatures'] > 0): ?>
                    <span class="badge bg-warning text-dark float-end"><?php echo $stats['candidatures']; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#affectations" data-bs-toggle="pill">
                    <i class="bi bi-diagram-3 me-2"></i> Affectations
                    <span class="badge bg-success float-end"><?php echo $stats['affectations']; ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#utilisateurs" data-bs-toggle="pill">
                    <i class="bi bi-people me-2"></i> Utilisateurs
                </a>
            </li>
        </ul>
        <hr class="bg-secondary mt-4">
        <a href="../index.php" class="btn btn-outline-light btn-sm w-100 mb-2">
            <i class="bi bi-arrow-left"></i> Retour au site
        </a>
        <a href="../logout.php" class="btn btn-danger btn-sm w-100">
            <i class="bi bi-box-arrow-right"></i> Déconnexion
        </a>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle me-2"></i> <?php echo $success_msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        <?php if ($error_msg): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-circle me-2"></i> <?php echo $error_msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Tableau de bord</h2>
                <p class="text-muted mb-0">Bienvenue, <?php echo htmlspecialchars($_SESSION['prenom']); ?> - Vue d'ensemble du système</p>
            </div>
            <div class="text-muted">
                <i class="bi bi-calendar"></i> <?php echo date('d/m/Y H:i'); ?>
            </div>
        </div>

        <div class="tab-content">
            <!-- Dashboard Tab -->
            <div class="tab-pane fade show active" id="dashboard">
                <!-- Stats -->
                <div class="row g-4 mb-4">
                    <div class="col-md-3">
                        <div class="stat-card primary">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <p class="mb-1 opacity-75">Total Stages</p>
                                    <p class="stat-number mb-0"><?php echo $stats['stages']; ?></p>
                                    <small class="opacity-50"><?php echo $stats['stages_ouverts']; ?> ouverts</small>
                                </div>
                                <i class="bi bi-briefcase fs-1 opacity-50"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card warning">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <p class="mb-1">Stagiaires</p>
                                    <p class="stat-number mb-0"><?php echo $stats['stagiaires']; ?></p>
                                    <small>inscrits</small>
                                </div>
                                <i class="bi bi-mortarboard fs-1 opacity-50"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card danger">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <p class="mb-1 opacity-75">En attente</p>
                                    <p class="stat-number mb-0"><?php echo $stats['candidatures']; ?></p>
                                    <small class="opacity-50">sur <?php echo $stats['candidatures_total']; ?> total</small>
                                </div>
                                <i class="bi bi-hourglass-split fs-1 opacity-50"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card success">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <p class="mb-1 opacity-75">Encadrants</p>
                                    <p class="stat-number mb-0"><?php echo $stats['encadrants']; ?></p>
                                    <small class="opacity-50">actifs</small>
                                </div>
                                <i class="bi bi-person-badge fs-1 opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row g-4">
                    <!-- Candidatures récentes -->
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span><i class="bi bi-clock-history me-2"></i> Candidatures récentes</span>
                                <a href="#candidatures" class="btn btn-sm btn-outline-dark" data-bs-toggle="pill">Voir tout</a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Candidat</th>
                                            <th>Stage</th>
                                            <th>Date</th>
                                            <th>Statut</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $recent = array_slice($candidatures, 0, 5);
                                        foreach ($recent as $c): 
                                            $status = getAdminStatusInfo($c['statut']);
                                        ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar me-2"><?php echo strtoupper(substr($c['prenom'], 0, 1) . substr($c['nom'], 0, 1)); ?></div>
                                                    <div>
                                                        <strong><?php echo htmlspecialchars($c['prenom'] . ' ' . $c['nom']); ?></strong>
                                                        <br><small class="text-muted"><?php echo htmlspecialchars($c['email']); ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge bg-secondary"><?php echo htmlspecialchars($c['departement']); ?></span><br>
                                                <small><?php echo htmlspecialchars($c['stage_titre']); ?></small>
                                            </td>
                                            <td><?php echo date('d/m/Y', strtotime($c['date_candidature'])); ?></td>
                                            <td><span class="status-badge <?php echo $status['class']; ?>"><?php echo $status['label']; ?></span></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Actions rapides -->
                    <div class="col-md-4">
                        <div class="card h-100">
                            <div class="card-header">
                                <i class="bi bi-lightning me-2"></i> Actions rapides
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <button class="btn btn-ey" data-bs-toggle="modal" data-bs-target="#addStageModal">
                                        <i class="bi bi-plus-circle me-2"></i> Ajouter un stage
                                    </button>
                                    <button class="btn btn-outline-dark" data-bs-toggle="modal" data-bs-target="#addUserModal">
                                        <i class="bi bi-person-plus me-2"></i> Ajouter un utilisateur
                                    </button>
                                    <a href="#candidatures" class="btn btn-outline-warning" data-bs-toggle="pill">
                                        <i class="bi bi-hourglass me-2"></i> Traiter les candidatures (<?php echo $stats['candidatures']; ?>)
                                    </a>
                                </div>
                                
                                <hr>
                                
                                <h6 class="text-muted mb-3">Statistiques</h6>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between small mb-1">
                                        <span>Taux d'acceptation</span>
                                        <strong><?php echo $taux_acceptation; ?>%</strong>
                                    </div>
                                    <div class="progress" style="height: 8px;">
                                        <div class="progress-bar bg-success" style="width: <?php echo $taux_acceptation; ?>%"></div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between small mb-1">
                                        <span>Stages occupés</span>
                                        <strong><?php echo $stats['affectations_actives']; ?>/<?php echo $stats['stages']; ?></strong>
                                    </div>
                                    <div class="progress" style="height: 8px;">
                                        <?php $pct = ($stats['stages'] > 0) ? round(($stats['affectations_actives'] / $stats['stages']) * 100) : 0; ?>
                                        <div class="progress-bar bg-info" style="width: <?php echo $pct; ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stages Tab -->
            <div class="tab-pane fade" id="stages">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4>Gestion des stages</h4>
                    <button class="btn btn-ey" data-bs-toggle="modal" data-bs-target="#addStageModal">
                        <i class="bi bi-plus-circle me-2"></i> Nouveau stage
                    </button>
                </div>
                <div class="card">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Titre</th>
                                    <th>Département</th>
                                    <th>Durée</th>
                                    <th>Lieu</th>
                                    <th>Places</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($stages as $s): 
                                    $status = getAdminStatusInfo($s['statut']);
                                ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($s['titre']); ?></strong></td>
                                    <td><span class="badge bg-secondary"><?php echo htmlspecialchars($s['departement']); ?></span></td>
                                    <td><?php echo htmlspecialchars($s['duree']); ?></td>
                                    <td><?php echo htmlspecialchars($s['lieu']); ?></td>
                                    <td><?php echo $s['places_disponibles']; ?></td>
                                    <td><span class="status-badge <?php echo $status['class']; ?>"><?php echo $status['label']; ?></span></td>
                                    <td>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="action" value="toggle_stage">
                                            <input type="hidden" name="stage_id" value="<?php echo $s['id']; ?>">
                                            <input type="hidden" name="current_status" value="<?php echo $s['statut']; ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-primary" title="Changer statut">
                                                <i class="bi bi-toggle-on"></i>
                                            </button>
                                        </form>
                                        <form method="POST" class="d-inline" onsubmit="return confirm('Supprimer ce stage?')">
                                            <input type="hidden" name="action" value="delete_stage">
                                            <input type="hidden" name="stage_id" value="<?php echo $s['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Candidatures Tab -->
            <div class="tab-pane fade" id="candidatures">
                <h4 class="mb-4">Gestion des candidatures</h4>
                <div class="card">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Candidat</th>
                                    <th>Stage</th>
                                    <th>Date</th>
                                    <th>Documents</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($candidatures as $c): 
                                    $status = getAdminStatusInfo($c['statut']);
                                ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar me-2"><?php echo strtoupper(substr($c['prenom'], 0, 1) . substr($c['nom'], 0, 1)); ?></div>
                                            <div>
                                                <strong><?php echo htmlspecialchars($c['prenom'] . ' ' . $c['nom']); ?></strong>
                                                <br><small class="text-muted"><?php echo htmlspecialchars($c['email']); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($c['departement']); ?></span><br>
                                        <small><?php echo htmlspecialchars($c['stage_titre']); ?></small>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($c['date_candidature'])); ?></td>
                                    <td>
                                        <?php if ($c['cv_path']): ?>
                                        <a href="../<?php echo htmlspecialchars($c['cv_path']); ?>" target="_blank" class="btn btn-sm btn-outline-info" title="Voir CV">
                                            <i class="bi bi-file-pdf"></i> CV
                                        </a>
                                        <?php endif; ?>
                                        <?php if ($c['lettre_motivation']): ?>
                                        <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#lettreModal<?php echo $c['id']; ?>" title="Voir lettre">
                                            <i class="bi bi-envelope"></i>
                                        </button>
                                        <?php endif; ?>
                                    </td>
                                    <td><span class="status-badge <?php echo $status['class']; ?>"><?php echo $status['label']; ?></span></td>
                                    <td>
                                        <?php if ($c['statut'] === 'en_attente'): ?>
                                        <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#acceptModal<?php echo $c['id']; ?>">
                                            <i class="bi bi-check"></i>
                                        </button>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="action" value="update_candidature">
                                            <input type="hidden" name="candidature_id" value="<?php echo $c['id']; ?>">
                                            <input type="hidden" name="statut" value="refusee">
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Refuser cette candidature?')">
                                                <i class="bi bi-x"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                
                                <!-- Modal Lettre -->
                                <div class="modal fade" id="lettreModal<?php echo $c['id']; ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Lettre de motivation - <?php echo htmlspecialchars($c['prenom'] . ' ' . $c['nom']); ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p><?php echo nl2br(htmlspecialchars($c['lettre_motivation'])); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Modal Accepter -->
                                <div class="modal fade" id="acceptModal<?php echo $c['id']; ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="POST">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Accepter la candidature</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <input type="hidden" name="action" value="update_candidature">
                                                    <input type="hidden" name="candidature_id" value="<?php echo $c['id']; ?>">
                                                    <input type="hidden" name="statut" value="acceptee">
                                                    
                                                    <p><strong>Candidat:</strong> <?php echo htmlspecialchars($c['prenom'] . ' ' . $c['nom']); ?></p>
                                                    <p><strong>Stage:</strong> <?php echo htmlspecialchars($c['stage_titre']); ?></p>
                                                    
                                                    <div class="mb-3">
                                                        <label class="form-label">Assigner un encadrant <span class="text-danger">*</span></label>
                                                        <select name="encadrant_id" class="form-select" required>
                                                            <option value="">Choisir un encadrant</option>
                                                            <?php foreach ($encadrants as $enc): ?>
                                                            <option value="<?php echo $enc['id']; ?>"><?php echo htmlspecialchars($enc['prenom'] . ' ' . $enc['nom'] . ' - ' . $enc['specialite']); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                                                    <button type="submit" class="btn btn-success">Accepter</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Affectations Tab -->
            <div class="tab-pane fade" id="affectations">
                <h4 class="mb-4">Affectations en cours</h4>
                <div class="card">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Stagiaire</th>
                                    <th>Stage</th>
                                    <th>Encadrant</th>
                                    <th>Période</th>
                                    <th>Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($affectations as $a): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($a['stagiaire_prenom'] . ' ' . $a['stagiaire_nom']); ?></strong>
                                        <br><small class="text-muted"><?php echo htmlspecialchars($a['stagiaire_email']); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($a['departement']); ?></span><br>
                                        <small><?php echo htmlspecialchars($a['stage_titre']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($a['encadrant_prenom'] . ' ' . $a['encadrant_nom']); ?></td>
                                    <td>
                                        <?php echo date('d/m/Y', strtotime($a['date_debut'])); ?> - 
                                        <?php echo date('d/m/Y', strtotime($a['date_fin'])); ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $aff_status = ($a['statut'] === 'en_cours') ? 'En cours' : ucfirst($a['statut']);
                                        $aff_class = ($a['statut'] === 'en_cours') ? 'bg-success' : 'bg-secondary';
                                        ?>
                                        <span class="badge <?php echo $aff_class; ?>"><?php echo $aff_status; ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Utilisateurs Tab -->
            <div class="tab-pane fade" id="utilisateurs">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4>Gestion des utilisateurs</h4>
                    <button class="btn btn-ey" data-bs-toggle="modal" data-bs-target="#addUserModal">
                        <i class="bi bi-person-plus me-2"></i> Nouvel utilisateur
                    </button>
                </div>
                <div class="card">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Utilisateur</th>
                                    <th>Email</th>
                                    <th>Rôle</th>
                                    <th>Spécialité</th>
                                    <th>Inscription</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($utilisateurs as $u): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar me-2"><?php echo strtoupper(substr($u['prenom'], 0, 1) . substr($u['nom'], 0, 1)); ?></div>
                                            <strong><?php echo htmlspecialchars($u['prenom'] . ' ' . $u['nom']); ?></strong>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($u['email']); ?></td>
                                    <td>
                                        <?php 
                                        $role_class = 'bg-secondary';
                                        if ($u['role'] === 'admin') $role_class = 'bg-danger';
                                        if ($u['role'] === 'encadrant') $role_class = 'bg-info';
                                        if ($u['role'] === 'stagiaire') $role_class = 'bg-warning text-dark';
                                        ?>
                                        <span class="badge <?php echo $role_class; ?>"><?php echo ucfirst($u['role']); ?></span>
                                    </td>
                                    <td><?php echo htmlspecialchars($u['specialite'] ? $u['specialite'] : '-'); ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($u['date_inscription'])); ?></td>
                                    <td>
                                        <?php if ($u['role'] !== 'admin'): ?>
                                        <form method="POST" class="d-inline" onsubmit="return confirm('Supprimer cet utilisateur?')">
                                            <input type="hidden" name="action" value="delete_user">
                                            <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Modal Ajouter Stage -->
    <div class="modal fade" id="addStageModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i> Nouveau stage</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_stage">
                        <div class="row">
                            <div class="col-md-8 mb-3">
                                <label class="form-label">Titre du stage <span class="text-danger">*</span></label>
                                <input type="text" name="titre" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Département <span class="text-danger">*</span></label>
                                <select name="departement" class="form-select" required>
                                    <option value="Audit">Audit</option>
                                    <option value="Conseil IT">Conseil IT</option>
                                    <option value="Fiscalité">Fiscalité</option>
                                    <option value="RH">RH</option>
                                    <option value="Marketing">Marketing</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description <span class="text-danger">*</span></label>
                            <textarea name="description" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Durée <span class="text-danger">*</span></label>
                                <input type="text" name="duree" class="form-control" placeholder="Ex: 6 mois" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Date début <span class="text-danger">*</span></label>
                                <input type="date" name="date_debut" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Date fin <span class="text-danger">*</span></label>
                                <input type="date" name="date_fin" class="form-control" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Lieu</label>
                                <input type="text" name="lieu" class="form-control" value="Casablanca">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Rémunération</label>
                                <input type="text" name="remuneration" class="form-control" placeholder="Ex: 1500 MAD/mois">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Places disponibles</label>
                                <input type="number" name="places" class="form-control" value="1" min="1">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Compétences requises</label>
                            <input type="text" name="competences" class="form-control" placeholder="Ex: Excel, Analyse financière, Rigueur">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-ey">Créer le stage</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Ajouter Utilisateur -->
    <div class="modal fade" id="addUserModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i> Nouvel utilisateur</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_user">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Prénom <span class="text-danger">*</span></label>
                                <input type="text" name="prenom" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Nom <span class="text-danger">*</span></label>
                                <input type="text" name="nom" class="form-control" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Mot de passe <span class="text-danger">*</span></label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Téléphone</label>
                            <input type="text" name="telephone" class="form-control">
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Rôle <span class="text-danger">*</span></label>
                                <select name="role" class="form-select" required>
                                    <option value="stagiaire">Stagiaire</option>
                                    <option value="encadrant">Encadrant</option>
                                    <option value="admin">Administrateur</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Spécialité</label>
                                <input type="text" name="specialite" class="form-control" placeholder="Pour les encadrants">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-ey">Créer l'utilisateur</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
