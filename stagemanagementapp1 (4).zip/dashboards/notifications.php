<?php
require_once dirname(__FILE__) . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: ../connexion.php');
    exit;
}

$pdo = getConnection();
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

// Récupérer les infos de l'utilisateur
$user_stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$user_stmt->execute([$user_id]);
$user_info = $user_stmt->fetch();

// Générer les notifications selon le rôle
$notifications = [];

if ($user_role === 'stagiaire') {
    // Candidatures en attente de réponse
    $pending = $pdo->prepare("
        SELECT 'candidature' as type, c.id, c.date_candidature, s.titre
        FROM candidatures c
        JOIN stages s ON c.stage_id = s.id
        WHERE c.stagiaire_id = ? AND c.statut = 'en_attente'
        ORDER BY c.date_candidature DESC
    ");
    $pending->execute([$user_id]);
    $notifications = array_merge($notifications, $pending->fetchAll());

    // Évaluations reçues
    $evals = $pdo->prepare("
        SELECT 'evaluation' as type, e.id, e.date_evaluation, a.id as affectation_id
        FROM evaluations e
        JOIN affectations a ON e.affectation_id = a.id
        WHERE a.stagiaire_id = ?
        ORDER BY e.date_evaluation DESC
        LIMIT 5
    ");
    $evals->execute([$user_id]);
    $notifications = array_merge($notifications, $evals->fetchAll());
}
elseif ($user_role === 'encadrant') {
    // Nouveaux stagiaires assignés
    $new_interns = $pdo->prepare("
        SELECT 'intern_assignement' as type, a.id, a.date_affectation, u.nom, u.prenom
        FROM affectations a
        JOIN utilisateurs u ON a.stagiaire_id = u.id
        WHERE a.encadrant_id = ? AND a.statut = 'en_cours'
        ORDER BY a.date_affectation DESC
        LIMIT 5
    ");
    $new_interns->execute([$user_id]);
    $notifications = array_merge($notifications, $new_interns->fetchAll());
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - EY</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ey-yellow: #ffe600;
            --ey-dark: #2e2e38;
            --ey-gray: #747480;
            --ey-light: #f6f6fa;
        }
        body { font-family: 'Inter', sans-serif; background-color: var(--ey-light); }
        .main-content { padding: 30px; margin-top: 70px; }
        .notification-item {
            background: white;
            border-left: 4px solid var(--ey-yellow);
            padding: 20px;
            margin-bottom: 12px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            transition: all 0.3s;
        }
        .notification-item:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .notification-item.read {
            opacity: 0.6;
        }
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .card-header { background: white; border-bottom: 1px solid #eee; font-weight: 600; }
        .btn-ey { background: var(--ey-yellow); color: var(--ey-dark); font-weight: 600; border: none; }
        .btn-ey:hover { background: #e6cf00; color: var(--ey-dark); }
    </style>
</head>
<body>
    <!-- Top Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="#">
                <div style="display: inline-block; background: var(--ey-yellow); color: var(--ey-dark); padding: 5px 12px; font-weight: 700; border-radius: 4px;">EY</div>
                <span class="ms-2">Notifications</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <div class="row">
            <div class="col-lg-8">
                <h2 class="mb-4"><i class="bi bi-bell me-2"></i> Notifications</h2>

                <?php if (empty($notifications)): ?>
                <div class="card">
                    <div class="card-body text-center py-5">
                        <i class="bi bi-inbox fs-1 text-muted"></i>
                        <h5 class="mt-3">Aucune notification</h5>
                        <p class="text-muted">Vous êtes à jour avec toutes vos notifications.</p>
                    </div>
                </div>
                <?php else: ?>
                    <?php foreach ($notifications as $notif): ?>
                    <div class="notification-item">
                        <?php if ($notif['type'] === 'candidature'): ?>
                            <div class="d-flex align-items-start">
                                <i class="bi bi-file-earmark text-warning fs-5 me-3"></i>
                                <div class="flex-grow-1">
                                    <h6 class="mb-1">Candidature en attente</h6>
                                    <p class="mb-1"><?php echo htmlspecialchars($notif['titre']); ?></p>
                                    <small class="text-muted"><i class="bi bi-calendar"></i> <?php echo date('d/m/Y à H:i', strtotime($notif['date_candidature'])); ?></small>
                                </div>
                                <span class="badge bg-warning text-dark">Attente</span>
                            </div>
                        <?php elseif ($notif['type'] === 'evaluation'): ?>
                            <div class="d-flex align-items-start">
                                <i class="bi bi-star text-info fs-5 me-3"></i>
                                <div class="flex-grow-1">
                                    <h6 class="mb-1">Nouvelle évaluation</h6>
                                    <p class="mb-1">Vous avez reçu une nouvelle évaluation</p>
                                    <small class="text-muted"><i class="bi bi-calendar"></i> <?php echo date('d/m/Y à H:i', strtotime($notif['date_evaluation'])); ?></small>
                                </div>
                                <span class="badge bg-info">Nouveau</span>
                            </div>
                        <?php elseif ($notif['type'] === 'intern_assignement'): ?>
                            <div class="d-flex align-items-start">
                                <i class="bi bi-person-plus text-success fs-5 me-3"></i>
                                <div class="flex-grow-1">
                                    <h6 class="mb-1">Nouveau stagiaire assigné</h6>
                                    <p class="mb-1"><?php echo htmlspecialchars($notif['prenom'] . ' ' . $notif['nom']); ?></p>
                                    <small class="text-muted"><i class="bi bi-calendar"></i> <?php echo date('d/m/Y à H:i', strtotime($notif['date_affectation'])); ?></small>
                                </div>
                                <span class="badge bg-success">Actif</span>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">Informations</div>
                    <div class="card-body">
                        <p><strong>Profil:</strong> <?php echo ucfirst($user_role); ?></p>
                        <p><strong>Nom:</strong> <?php echo htmlspecialchars($user_info['prenom'] . ' ' . $user_info['nom']); ?></p>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($user_info['email']); ?></p>
                        <a href="<?php echo $user_role === 'stagiaire' ? 'stagiaire.php' : ($user_role === 'encadrant' ? 'encadrant.php' : 'admin.php'); ?>" class="btn btn-ey btn-sm w-100">
                            <i class="bi bi-arrow-left"></i> Retour au dashboard
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
