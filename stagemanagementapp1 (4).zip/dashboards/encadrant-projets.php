<?php
require_once dirname(__FILE__) . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'encadrant') {
    header('Location: ../connexion.php');
    exit;
}

$pdo = getConnection();
$encadrant_id = $_SESSION['user_id'];
$user_stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$user_stmt->execute([$encadrant_id]);
$user_info = $user_stmt->fetch();

$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'add_task') {
        try {
            $stmt = $pdo->prepare("INSERT INTO taches_projet (affectation_id, titre, description, date_limite, priorite, statut) VALUES (?, ?, ?, ?, ?, 'a_faire')");
            $stmt->execute([
                $_POST['affectation_id'],
                $_POST['titre'],
                $_POST['description'],
                $_POST['date_limite'],
                $_POST['priorite']
            ]);
            $success_msg = "Tâche ajoutée avec succès!";
        } catch (PDOException $e) {
            $error_msg = "Erreur: " . $e->getMessage();
        }
    }
    elseif (isset($_POST['action']) && $_POST['action'] === 'update_task') {
        try {
            $stmt = $pdo->prepare("UPDATE taches_projet SET statut = ?, priorite = ? WHERE id = ?");
            $stmt->execute([
                $_POST['statut'],
                $_POST['priorite'],
                $_POST['task_id']
            ]);
            $success_msg = "Tâche mise à jour avec succès!";
        } catch (PDOException $e) {
            $error_msg = "Erreur: " . $e->getMessage();
        }
    }
    elseif (isset($_POST['action']) && $_POST['action'] === 'delete_task') {
        try {
            $stmt = $pdo->prepare("DELETE FROM taches_projet WHERE id = ?");
            $stmt->execute([$_POST['task_id']]);
            $success_msg = "Tâche supprimée!";
        } catch (PDOException $e) {
            $error_msg = "Erreur: " . $e->getMessage();
        }
    }
}

// Récupérer les affectations et leurs tâches
$affectations = $pdo->prepare("
    SELECT a.*, u.nom, u.prenom, s.titre as stage_titre
    FROM affectations a
    JOIN utilisateurs u ON a.stagiaire_id = u.id
    JOIN stages s ON a.stage_id = s.id
    WHERE a.encadrant_id = ? AND a.statut = 'en_cours'
    ORDER BY a.date_affectation DESC
");
$affectations->execute([$encadrant_id]);
$mes_affectations = $affectations->fetchAll();

// Récupérer les tâches
$taches_query = $pdo->prepare("
    SELECT t.*, u.nom, u.prenom, s.titre as stage_titre, a.id as affectation_id
    FROM taches_projet t
    JOIN affectations a ON t.affectation_id = a.id
    JOIN utilisateurs u ON a.stagiaire_id = u.id
    JOIN stages s ON a.stage_id = s.id
    WHERE a.encadrant_id = ?
    ORDER BY t.priorite DESC, t.date_limite ASC
");
$taches_query->execute([$encadrant_id]);
$taches = $taches_query->fetchAll();

// Statistiques des tâches
$stats_taches = [
    'total' => 0,
    'a_faire' => 0,
    'en_cours' => 0,
    'terminees' => 0
];
foreach ($taches as $t) {
    $stats_taches['total']++;
    $stats_taches[$t['statut']]++;
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Projets - EY</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ey-yellow: #ffe600;
            --ey-dark: #2e2e38;
            --ey-gray: #747480;
            --ey-light: #f6f6fa;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--ey-light);
        }
        .sidebar {
            background: linear-gradient(180deg, var(--ey-dark) 0%, #1a1a24 100%);
            min-height: 100vh;
            position: fixed;
            width: 260px;
            padding: 20px;
            z-index: 1000;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 5px;
            transition: all 0.3s;
            text-decoration: none;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,230,0,0.15);
        }
        .sidebar .nav-link.active {
            border-left: 3px solid var(--ey-yellow);
        }
        .main-content {
            margin-left: 260px;
            padding: 30px;
        }
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-3px);
        }
        .task-card {
            border-left: 4px solid var(--ey-yellow);
            background: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 12px;
            transition: all 0.3s;
        }
        .task-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .task-card.haute-priorite {
            border-left-color: #dc3545;
        }
        .task-card.moyenne-priorite {
            border-left-color: var(--ey-yellow);
        }
        .task-card.basse-priorite {
            border-left-color: #28a745;
        }
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        .status-a_faire { background: #f8f9fa; color: #495057; }
        .status-en_cours { background: #fff3cd; color: #856404; }
        .status-terminees { background: #d4edda; color: #155724; }
        .ey-logo {
            background: var(--ey-yellow);
            color: var(--ey-dark);
            padding: 5px 12px;
            font-weight: 700;
            font-size: 1.5rem;
        }
        .btn-ey {
            background: var(--ey-yellow);
            color: var(--ey-dark);
            font-weight: 600;
            border: none;
        }
        .btn-ey:hover {
            background: #e6cf00;
            color: var(--ey-dark);
        }
        .avatar {
            width: 40px;
            height: 40px;
            background: var(--ey-yellow);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: var(--ey-dark);
            font-size: 0.9rem;
        }
        @media (max-width: 768px) {
            .sidebar { display: none; }
            .main-content { margin-left: 0; }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="text-center mb-4">
            <span class="ey-logo">EY</span>
            <p class="text-white mt-3 mb-1">Espace Encadrant</p>
            <small class="text-white-50"><?php echo htmlspecialchars($user_info['prenom'] . ' ' . $user_info['nom']); ?></small>
        </div>
        <hr class="bg-secondary">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="encadrant.php">
                    <i class="bi bi-house me-2"></i> Tableau de bord
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="encadrant-stagiaires.php">
                    <i class="bi bi-people me-2"></i> Mes stagiaires
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="encadrant-evaluations.php">
                    <i class="bi bi-star me-2"></i> Évaluations
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'encadrant-projets.php' ? 'active' : ''; ?>" href="encadrant-projets.php">
                    <i class="bi bi-kanban me-2"></i> Gestion Projets
                </a>
            </li>
        </ul>
        <hr class="bg-secondary mt-4">
        <a href="../index.php" class="btn btn-outline-light btn-sm w-100 mb-2">
            <i class="bi bi-arrow-left"></i> Retour au site
        </a>
        <a href="../logout.php" class="btn btn-danger btn-sm w-100">
            <i class="bi bi-box-arrow-right"></i> Déconnexion
        </a>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Gestion des Projets</h2>
                <p class="text-muted mb-0">Suivi des tâches et jalons des stagiaires</p>
            </div>
            <div class="avatar"><?php echo strtoupper(substr($user_info['prenom'], 0, 1) . substr($user_info['nom'], 0, 1)); ?></div>
        </div>

        <!-- Messages -->
        <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle me-2"></i> <?php echo $success_msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        <?php if ($error_msg): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-circle me-2"></i> <?php echo $error_msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <p class="mb-1 text-muted small">Total tâches</p>
                    <p class="fs-3 fw-bold mb-0"><?php echo $stats_taches['total']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <p class="mb-1 text-muted small">À faire</p>
                    <p class="fs-3 fw-bold mb-0 text-secondary"><?php echo $stats_taches['a_faire']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <p class="mb-1 text-muted small">En cours</p>
                    <p class="fs-3 fw-bold mb-0 text-warning"><?php echo $stats_taches['en_cours']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <p class="mb-1 text-muted small">Terminées</p>
                    <p class="fs-3 fw-bold mb-0 text-success"><?php echo $stats_taches['terminees']; ?></p>
                </div>
            </div>
        </div>

        <!-- Affectations et Tâches -->
        <div class="row">
            <!-- Ajouter une tâche -->
            <div class="col-lg-4 mb-4">
                <div class="card">
                    <div class="card-header">
                        <i class="bi bi-plus-circle me-2"></i> Nouvelle tâche
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="add_task">
                            
                            <div class="mb-3">
                                <label class="form-label"><strong>Stagiaire</strong></label>
                                <select name="affectation_id" class="form-select" required>
                                    <option selected disabled>Choisir un stagiaire...</option>
                                    <?php foreach ($mes_affectations as $aff): ?>
                                    <option value="<?php echo $aff['id']; ?>">
                                        <?php echo htmlspecialchars($aff['prenom'] . ' ' . $aff['nom']); ?> - <?php echo htmlspecialchars($aff['stage_titre']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><strong>Titre de la tâche</strong></label>
                                <input type="text" name="titre" class="form-control" required placeholder="Ex: Implémenter la base de données">
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><strong>Description</strong></label>
                                <textarea name="description" class="form-control" rows="3" placeholder="Détails de la tâche..."></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><strong>Date limite</strong></label>
                                <input type="date" name="date_limite" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><strong>Priorité</strong></label>
                                <select name="priorite" class="form-select" required>
                                    <option value="basse">Basse</option>
                                    <option value="moyenne" selected>Moyenne</option>
                                    <option value="haute">Haute</option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-ey w-100">
                                <i class="bi bi-plus"></i> Ajouter la tâche
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Liste des tâches -->
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <i class="bi bi-list-check me-2"></i> Liste des tâches
                    </div>
                    <div class="card-body">
                        <?php if (empty($taches)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-inbox fs-1 text-muted"></i>
                            <p class="text-muted mt-3">Aucune tâche pour le moment</p>
                        </div>
                        <?php else: ?>
                        <?php foreach ($taches as $tache): ?>
                        <div class="task-card <?php echo $tache['priorite']; ?>-priorite">
                            <div class="row align-items-start">
                                <div class="col">
                                    <h6 class="mb-2"><?php echo htmlspecialchars($tache['titre']); ?></h6>
                                    <p class="small text-muted mb-2">
                                        <i class="bi bi-person"></i> <?php echo htmlspecialchars($tache['prenom'] . ' ' . $tache['nom']); ?>
                                    </p>
                                    <?php if ($tache['description']): ?>
                                    <p class="small mb-2"><?php echo htmlspecialchars($tache['description']); ?></p>
                                    <?php endif; ?>
                                    <div class="d-flex gap-2 flex-wrap">
                                        <span class="status-badge status-<?php echo $tache['statut']; ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $tache['statut'])); ?>
                                        </span>
                                        <small class="text-muted">
                                            <i class="bi bi-calendar"></i> <?php echo date('d/m/Y', strtotime($tache['date_limite'])); ?>
                                        </small>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="action" value="update_task">
                                        <input type="hidden" name="task_id" value="<?php echo $tache['id']; ?>">
                                        <select name="statut" class="form-select form-select-sm" onchange="this.form.submit()" style="width: 140px;">
                                            <option value="a_faire" <?php echo $tache['statut'] === 'a_faire' ? 'selected' : ''; ?>>À faire</option>
                                            <option value="en_cours" <?php echo $tache['statut'] === 'en_cours' ? 'selected' : ''; ?>>En cours</option>
                                            <option value="terminees" <?php echo $tache['statut'] === 'terminees' ? 'selected' : ''; ?>>Terminée</option>
                                        </select>
                                        <input type="hidden" name="priorite" value="<?php echo $tache['priorite']; ?>">
                                    </form>
                                    <form method="POST" class="d-inline mt-2">
                                        <input type="hidden" name="action" value="delete_task">
                                        <input type="hidden" name="task_id" value="<?php echo $tache['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Êtes-vous sûr?')">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
