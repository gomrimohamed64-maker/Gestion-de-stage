<?php
require_once dirname(__FILE__) . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'stagiaire') {
    header('Location: ../connexion.php');
    exit;
}

$pdo = getConnection();
$user_id = $_SESSION['user_id'];

// Récupérer les infos du stagiaire
$user_stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$user_stmt->execute([$user_id]);
$user_info = $user_stmt->fetch();

// Récupérer le stage actuel
$affectation = $pdo->prepare("
    SELECT a.* FROM affectations a
    WHERE a.stagiaire_id = ? AND a.statut = 'en_cours'
    LIMIT 1
");
$affectation->execute([$user_id]);
$mon_stage = $affectation->fetch();

$taches = [];
if ($mon_stage) {
    // Récupérer les tâches du stagiaire
    $taches_query = $pdo->prepare("
        SELECT * FROM taches_projet
        WHERE affectation_id = ?
        ORDER BY priorite DESC, date_limite ASC
    ");
    $taches_query->execute([$mon_stage['id']]);
    $taches = $taches_query->fetchAll();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    try {
        $stmt = $pdo->prepare("UPDATE taches_projet SET statut = ? WHERE id = ?");
        $stmt->execute([$_POST['statut'], $_POST['task_id']]);
    } catch (PDOException $e) {
        // Handle error silently
    }
}

// Statistiques des tâches
$stats_taches = [
    'total' => count($taches),
    'a_faire' => 0,
    'en_cours' => 0,
    'terminees' => 0
];
foreach ($taches as $t) {
    $stats_taches[$t['statut']]++;
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Tâches - EY</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ey-yellow: #ffe600;
            --ey-dark: #2e2e38;
            --ey-gray: #747480;
            --ey-light: #f6f6fa;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--ey-light);
        }
        .sidebar {
            background: linear-gradient(180deg, var(--ey-dark) 0%, #1a1a24 100%);
            min-height: 100vh;
            position: fixed;
            width: 260px;
            padding: 20px;
            z-index: 1000;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 5px;
            transition: all 0.3s;
            text-decoration: none;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,230,0,0.15);
        }
        .sidebar .nav-link.active {
            border-left: 3px solid var(--ey-yellow);
        }
        .main-content {
            margin-left: 260px;
            padding: 30px;
        }
        .task-card {
            border-left: 4px solid var(--ey-yellow);
            background: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 12px;
            transition: all 0.3s;
        }
        .task-card.haute-priorite {
            border-left-color: #dc3545;
        }
        .task-card.moyenne-priorite {
            border-left-color: var(--ey-yellow);
        }
        .task-card.basse-priorite {
            border-left-color: #28a745;
        }
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        .status-a_faire { background: #f8f9fa; color: #495057; }
        .status-en_cours { background: #fff3cd; color: #856404; }
        .status-terminees { background: #d4edda; color: #155724; }
        .btn-ey {
            background: var(--ey-yellow);
            color: var(--ey-dark);
            font-weight: 600;
            border: none;
        }
        .btn-ey:hover {
            background: #e6cf00;
            color: var(--ey-dark);
        }
        .ey-logo {
            background: var(--ey-yellow);
            color: var(--ey-dark);
            padding: 5px 12px;
            font-weight: 700;
            font-size: 1.5rem;
        }
        .avatar {
            width: 45px;
            height: 45px;
            background: var(--ey-yellow);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: var(--ey-dark);
        }
        @media (max-width: 768px) {
            .sidebar { display: none; }
            .main-content { margin-left: 0; }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="text-center mb-4">
            <span class="ey-logo">EY</span>
            <p class="text-white mt-3 mb-1">Espace Stagiaire</p>
            <small class="text-white-50"><?php echo htmlspecialchars($user_info['prenom'] . ' ' . $user_info['nom']); ?></small>
        </div>
        <hr class="bg-secondary">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="stagiaire.php">
                    <i class="bi bi-house me-2"></i> Tableau de bord
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="stagiaire-candidatures.php">
                    <i class="bi bi-file-earmark-text me-2"></i> Mes candidatures
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'stagiaire-projets.php' ? 'active' : ''; ?>" href="stagiaire-projets.php">
                    <i class="bi bi-kanban me-2"></i> Mes tâches
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="stagiaire-profil.php">
                    <i class="bi bi-person me-2"></i> Mon profil
                </a>
            </li>
        </ul>
        <hr class="bg-secondary mt-4">
        <a href="../index.php" class="btn btn-outline-light btn-sm w-100 mb-2">
            <i class="bi bi-arrow-left"></i> Retour au site
        </a>
        <a href="../logout.php" class="btn btn-danger btn-sm w-100">
            <i class="bi bi-box-arrow-right"></i> Déconnexion
        </a>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Mes Tâches</h2>
                <p class="text-muted mb-0">Suivi de vos tâches et jalons</p>
            </div>
            <div class="avatar"><?php echo strtoupper(substr($user_info['prenom'], 0, 1) . substr($user_info['nom'], 0, 1)); ?></div>
        </div>

        <?php if ($mon_stage): ?>
        <!-- Stats -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="card text-center py-3">
                    <p class="mb-1 text-muted small">Total tâches</p>
                    <p class="fs-3 fw-bold mb-0"><?php echo $stats_taches['total']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center py-3">
                    <p class="mb-1 text-muted small">À faire</p>
                    <p class="fs-3 fw-bold mb-0 text-secondary"><?php echo $stats_taches['a_faire']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center py-3">
                    <p class="mb-1 text-muted small">En cours</p>
                    <p class="fs-3 fw-bold mb-0 text-warning"><?php echo $stats_taches['en_cours']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center py-3">
                    <p class="mb-1 text-muted small">Terminées</p>
                    <p class="fs-3 fw-bold mb-0 text-success"><?php echo $stats_taches['terminees']; ?></p>
                </div>
            </div>
        </div>

        <!-- Tâches -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-list-check me-2"></i> Liste de vos tâches
            </div>
            <div class="card-body">
                <?php if (empty($taches)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-inbox fs-1 text-muted"></i>
                    <p class="text-muted mt-3">Aucune tâche assignée pour le moment</p>
                </div>
                <?php else: ?>
                <?php foreach ($taches as $tache): ?>
                <div class="task-card <?php echo $tache['priorite']; ?>-priorite">
                    <div class="row align-items-start">
                        <div class="col">
                            <h6 class="mb-2"><?php echo htmlspecialchars($tache['titre']); ?></h6>
                            <?php if ($tache['description']): ?>
                            <p class="small text-muted mb-2"><?php echo htmlspecialchars($tache['description']); ?></p>
                            <?php endif; ?>
                            <div class="d-flex gap-2 flex-wrap align-items-center">
                                <span class="status-badge status-<?php echo $tache['statut']; ?>">
                                    <?php echo ucfirst(str_replace('_', ' ', $tache['statut'])); ?>
                                </span>
                                <small class="text-muted">
                                    <i class="bi bi-calendar"></i> <?php echo date('d/m/Y', strtotime($tache['date_limite'])); ?>
                                </small>
                                <small class="badge bg-light text-dark">
                                    <?php 
                                    $now = new DateTime();
                                    $deadline = new DateTime($tache['date_limite']);
                                    $diff = $deadline->diff($now)->days;
                                    echo $diff <= 0 ? 'Aujourd\'hui' : $diff . ' jour(s)';
                                    ?>
                                </small>
                            </div>
                        </div>
                        <div class="col-auto">
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="action" value="update_status">
                                <input type="hidden" name="task_id" value="<?php echo $tache['id']; ?>">
                                <select name="statut" class="form-select form-select-sm" onchange="this.form.submit()" style="width: 140px;">
                                    <option value="a_faire" <?php echo $tache['statut'] === 'a_faire' ? 'selected' : ''; ?>>À faire</option>
                                    <option value="en_cours" <?php echo $tache['statut'] === 'en_cours' ? 'selected' : ''; ?>>En cours</option>
                                    <option value="terminees" <?php echo $tache['statut'] === 'terminees' ? 'selected' : ''; ?>>Terminée</option>
                                </select>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php else: ?>
        <div class="alert alert-info">
            <i class="bi bi-info-circle me-2"></i> Vous n'avez pas de stage en cours pour le moment.
        </div>
        <?php endif; ?>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
