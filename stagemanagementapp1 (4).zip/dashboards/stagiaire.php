<?php
require_once dirname(__FILE__) . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'stagiaire') {
    header('Location: ../connexion.php');
    exit;
}

$pdo = getConnection();
$user_id = $_SESSION['user_id'];

// Récupérer les infos du stagiaire
$user_stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$user_stmt->execute([$user_id]);
$user_info = $user_stmt->fetch();

// Mes candidatures
$candidatures = $pdo->prepare("
    SELECT c.*, s.titre, s.departement, s.duree, s.date_debut, s.date_fin, s.lieu
    FROM candidatures c
    JOIN stages s ON c.stage_id = s.id
    WHERE c.stagiaire_id = ?
    ORDER BY c.date_candidature DESC
");
$candidatures->execute([$user_id]);
$mes_candidatures = $candidatures->fetchAll();

// Mon stage actuel (si accepté)
$affectation = $pdo->prepare("
    SELECT a.*, s.titre, s.departement, s.description, 
           u.nom as encadrant_nom, u.prenom as encadrant_prenom, 
           u.email as encadrant_email, u.telephone as encadrant_tel
    FROM affectations a
    JOIN stages s ON a.stage_id = s.id
    JOIN utilisateurs u ON a.encadrant_id = u.id
    WHERE a.stagiaire_id = ? AND a.statut = 'en_cours'
");
$affectation->execute([$user_id]);
$mon_stage = $affectation->fetch();

// Mes évaluations
$evaluations = [];
if ($mon_stage) {
    $eval = $pdo->prepare("SELECT * FROM evaluations WHERE affectation_id = ? ORDER BY date_evaluation DESC");
    $eval->execute([$mon_stage['id']]);
    $evaluations = $eval->fetchAll();
}

// Stages disponibles pour postuler
$stages_dispo = $pdo->query("SELECT * FROM stages WHERE statut = 'ouvert' ORDER BY date_creation DESC LIMIT 6")->fetchAll();

// Statistiques
$stats_candidatures = count($mes_candidatures);
$stats_acceptees = 0;
$stats_attente = 0;
foreach ($mes_candidatures as $c) {
    if ($c['statut'] === 'acceptee') $stats_acceptees++;
    if ($c['statut'] === 'en_attente') $stats_attente++;
}

// Fonction pour obtenir le statut formaté
function getStatusInfo($statut) {
    switch($statut) {
        case 'en_attente':
            return ['class' => 'status-en_attente', 'label' => 'En attente'];
        case 'acceptee':
            return ['class' => 'status-acceptee', 'label' => 'Acceptée'];
        case 'refusee':
            return ['class' => 'status-refusee', 'label' => 'Refusée'];
        default:
            return ['class' => 'bg-secondary', 'label' => $statut];
    }
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espace Stagiaire - EY</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ey-yellow: #ffe600;
            --ey-dark: #2e2e38;
            --ey-gray: #747480;
            --ey-light: #f6f6fa;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--ey-light);
        }
        .sidebar {
            background: linear-gradient(180deg, var(--ey-dark) 0%, #1a1a24 100%);
            min-height: 100vh;
            position: fixed;
            width: 260px;
            padding: 20px;
            z-index: 1000;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 5px;
            transition: all 0.3s;
            text-decoration: none;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,230,0,0.15);
        }
        .sidebar .nav-link.active {
            border-left: 3px solid var(--ey-yellow);
        }
        .main-content {
            margin-left: 260px;
            padding: 30px;
        }
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-3px);
        }
        .stat-card.primary {
            background: linear-gradient(135deg, var(--ey-dark), #3a3a48);
            color: white;
        }
        .stat-card.warning {
            background: linear-gradient(135deg, var(--ey-yellow), #e6cf00);
            color: var(--ey-dark);
        }
        .stat-card.success {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
        }
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
        }
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .card-header {
            background: white;
            border-bottom: 1px solid #eee;
            font-weight: 600;
        }
        .btn-ey {
            background: var(--ey-yellow);
            color: var(--ey-dark);
            font-weight: 600;
            border: none;
        }
        .btn-ey:hover {
            background: #e6cf00;
            color: var(--ey-dark);
        }
        .ey-logo {
            background: var(--ey-yellow);
            color: var(--ey-dark);
            padding: 5px 12px;
            font-weight: 700;
            font-size: 1.5rem;
        }
        .stage-card {
            border-left: 4px solid var(--ey-yellow);
            transition: all 0.3s;
        }
        .stage-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        .avatar {
            width: 45px;
            height: 45px;
            background: var(--ey-yellow);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: var(--ey-dark);
        }
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        .status-en_attente { background: #fff3cd; color: #856404; }
        .status-acceptee { background: #d4edda; color: #155724; }
        .status-refusee { background: #f8d7da; color: #721c24; }
        @media (max-width: 768px) {
            .sidebar { display: none; }
            .main-content { margin-left: 0; }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="text-center mb-4">
            <span class="ey-logo">EY</span>
            <p class="text-white mt-3 mb-1">Espace Stagiaire</p>
            <small class="text-white-50"><?php echo htmlspecialchars($user_info['prenom'] . ' ' . $user_info['nom']); ?></small>
        </div>
        <hr class="bg-secondary">
        <ul class="nav flex-column">
            <!-- Fixed navigation links to real pages -->
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'stagiaire.php' ? 'active' : ''; ?>" href="stagiaire.php">
                    <i class="bi bi-house me-2"></i> Tableau de bord
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'stagiaire-candidatures.php' ? 'active' : ''; ?>" href="stagiaire-candidatures.php">
                    <i class="bi bi-file-earmark-text me-2"></i> Mes candidatures
                    <?php if ($stats_attente > 0): ?>
                    <span class="badge bg-warning text-dark float-end"><?php echo $stats_attente; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'stagiaire-projets.php' ? 'active' : ''; ?>" href="stagiaire-projets.php">
                    <i class="bi bi-kanban me-2"></i> Mes tâches
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === '../stages.php' ? 'active' : ''; ?>" href="../stages.php">
                    <i class="bi bi-briefcase me-2"></i> Offres de stage
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'stagiaire-profil.php' ? 'active' : ''; ?>" href="stagiaire-profil.php">
                    <i class="bi bi-person me-2"></i> Mon profil
                </a>
            </li>
        </ul>
        <hr class="bg-secondary mt-4">
        <a href="../index.php" class="btn btn-outline-light btn-sm w-100 mb-2">
            <i class="bi bi-arrow-left"></i> Retour au site
        </a>
        <a href="../logout.php" class="btn btn-danger btn-sm w-100">
            <i class="bi bi-box-arrow-right"></i> Déconnexion
        </a>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Bonjour, <?php echo htmlspecialchars($_SESSION['prenom']); ?> !</h2>
                <p class="text-muted mb-0">Bienvenue sur votre espace personnel</p>
            </div>
            <div class="d-flex align-items-center">
                <span class="text-muted me-3"><i class="bi bi-calendar"></i> <?php echo date('d/m/Y'); ?></span>
                <div class="avatar"><?php echo strtoupper(substr($user_info['prenom'], 0, 1) . substr($user_info['nom'], 0, 1)); ?></div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="stat-card primary">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 opacity-75">Total candidatures</p>
                            <p class="stat-number mb-0"><?php echo $stats_candidatures; ?></p>
                        </div>
                        <i class="bi bi-file-earmark-text fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card warning">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1">En attente</p>
                            <p class="stat-number mb-0"><?php echo $stats_attente; ?></p>
                        </div>
                        <i class="bi bi-hourglass-split fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card success">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 opacity-75">Acceptées</p>
                            <p class="stat-number mb-0"><?php echo $stats_acceptees; ?></p>
                        </div>
                        <i class="bi bi-check-circle fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stage en cours -->
        <?php if ($mon_stage): ?>
        <div class="card mb-4 border-success">
            <div class="card-header bg-success text-white">
                <i class="bi bi-briefcase-fill me-2"></i> Mon stage en cours
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <h4><?php echo htmlspecialchars($mon_stage['titre']); ?></h4>
                        <span class="badge bg-dark mb-3"><?php echo htmlspecialchars($mon_stage['departement']); ?></span>
                        <p class="text-muted"><?php echo htmlspecialchars($mon_stage['description']); ?></p>
                        <hr>
                        <div class="row">
                            <div class="col-md-6">
                                <p class="mb-1"><strong><i class="bi bi-person-badge"></i> Encadrant:</strong></p>
                                <p><?php echo htmlspecialchars($mon_stage['encadrant_prenom'] . ' ' . $mon_stage['encadrant_nom']); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p class="mb-1"><strong><i class="bi bi-envelope"></i> Contact:</strong></p>
                                <p><a href="mailto:<?php echo htmlspecialchars($mon_stage['encadrant_email']); ?>"><?php echo htmlspecialchars($mon_stage['encadrant_email']); ?></a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <h6 class="mb-3"><i class="bi bi-star"></i> Mes évaluations</h6>
                                <?php if (empty($evaluations)): ?>
                                    <p class="text-muted mb-0">Aucune évaluation</p>
                                <?php else: ?>
                                    <?php foreach ($evaluations as $e): ?>
                                    <div class="mb-2 p-2 bg-white rounded">
                                        <span class="badge bg-warning text-dark fs-5"><?php echo $e['note']; ?>/20</span>
                                        <small class="d-block text-muted mt-1"><?php echo date('d/m/Y', strtotime($e['date_evaluation'])); ?></small>
                                    </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Mes candidatures -->
        <div class="card mb-4" id="candidatures">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-file-earmark-text me-2"></i> Mes candidatures</span>
                <a href="../stages.php" class="btn btn-ey btn-sm">
                    <i class="bi bi-plus-circle"></i> Nouvelle candidature
                </a>
            </div>
            <div class="card-body">
                <?php if (empty($mes_candidatures)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-inbox fs-1 text-muted"></i>
                    <p class="text-muted mt-3">Vous n'avez pas encore postulé à un stage.</p>
                    <a href="../stages.php" class="btn btn-ey">Découvrir les stages</a>
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Stage</th>
                                <th>Département</th>
                                <th>Lieu</th>
                                <th>Durée</th>
                                <th>Date candidature</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($mes_candidatures as $c): ?>
                            <?php $status = getStatusInfo($c['statut']); ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($c['titre']); ?></strong></td>
                                <td><span class="badge bg-secondary"><?php echo htmlspecialchars($c['departement']); ?></span></td>
                                <td><i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($c['lieu'] ? $c['lieu'] : 'Non spécifié'); ?></td>
                                <td><?php echo htmlspecialchars($c['duree']); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($c['date_candidature'])); ?></td>
                                <td><span class="status-badge <?php echo $status['class']; ?>"><?php echo $status['label']; ?></span></td>
                                <td>
                                    <a href="../stage-detail.php?id=<?php echo $c['stage_id']; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Stages disponibles -->
        <div class="card" id="stages-dispo">
            <div class="card-header">
                <i class="bi bi-star me-2"></i> Stages disponibles pour vous
            </div>
            <div class="card-body">
                <div class="row g-4">
                    <?php foreach ($stages_dispo as $stage): ?>
                    <div class="col-md-4">
                        <div class="card stage-card h-100">
                            <div class="card-body">
                                <span class="badge bg-dark mb-2"><?php echo htmlspecialchars($stage['departement']); ?></span>
                                <h6 class="card-title"><?php echo htmlspecialchars($stage['titre']); ?></h6>
                                <p class="card-text small text-muted"><?php echo substr(htmlspecialchars($stage['description']), 0, 80); ?>...</p>
                                <hr>
                                <div class="d-flex justify-content-between small text-muted">
                                    <span><i class="bi bi-clock"></i> <?php echo $stage['duree']; ?></span>
                                    <span><i class="bi bi-geo-alt"></i> <?php echo $stage['lieu'] ? $stage['lieu'] : 'Casablanca'; ?></span>
                                </div>
                            </div>
                            <div class="card-footer bg-white border-0">
                                <a href="../stage-detail.php?id=<?php echo $stage['id']; ?>" class="btn btn-ey btn-sm w-100">
                                    <i class="bi bi-arrow-right"></i> Voir & Postuler
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
