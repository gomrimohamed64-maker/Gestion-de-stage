<?php
require_once dirname(__FILE__) . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'encadrant') {
    header('Location: ../connexion.php');
    exit;
}

$pdo = getConnection();
$encadrant_id = $_SESSION['user_id'];

// Récupérer infos encadrant
$user_stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$user_stmt->execute([$encadrant_id]);
$user_info = $user_stmt->fetch();

// Traitement évaluation
$success_msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'evaluer') {
    $competences = isset($_POST['competences_acquises']) ? $_POST['competences_acquises'] : '';
    $points = isset($_POST['points_amelioration']) ? $_POST['points_amelioration'] : '';
    
    $stmt = $pdo->prepare("INSERT INTO evaluations (affectation_id, note, commentaire, competences_acquises, points_amelioration, date_evaluation) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->execute([
        $_POST['affectation_id'], 
        $_POST['note'], 
        $_POST['commentaire'],
        $competences,
        $points
    ]);
    $success_msg = "Évaluation enregistrée avec succès!";
}

// Mes stagiaires
$stagiaires = $pdo->prepare("
    SELECT a.*, u.nom, u.prenom, u.email, u.telephone, 
           s.titre as stage_titre, s.departement, s.date_debut, s.date_fin, 
           a.statut as affectation_statut
    FROM affectations a
    JOIN utilisateurs u ON a.stagiaire_id = u.id
    JOIN stages s ON a.stage_id = s.id
    WHERE a.encadrant_id = ?
    ORDER BY a.date_affectation DESC
");
$stagiaires->execute([$encadrant_id]);
$mes_stagiaires = $stagiaires->fetchAll();

// Statistiques
$eval_count_stmt = $pdo->prepare("SELECT COUNT(*) FROM evaluations e JOIN affectations a ON e.affectation_id = a.id WHERE a.encadrant_id = ?");
$eval_count_stmt->execute([$encadrant_id]);
$total_evaluations = $eval_count_stmt->fetchColumn();

$stagiaires_actifs = 0;
foreach ($mes_stagiaires as $s) {
    if ($s['affectation_statut'] === 'en_cours') $stagiaires_actifs++;
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espace Encadrant - EY</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ey-yellow: #ffe600;
            --ey-dark: #2e2e38;
            --ey-gray: #747480;
            --ey-light: #f6f6fa;
        }
        body { font-family: 'Inter', sans-serif; background-color: var(--ey-light); }
        .sidebar {
            background: linear-gradient(180deg, var(--ey-dark) 0%, #1a1a24 100%);
            min-height: 100vh;
            position: fixed;
            width: 260px;
            padding: 20px;
            z-index: 1000;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 5px;
            transition: all 0.3s;
            text-decoration: none;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,230,0,0.15);
        }
        .sidebar .nav-link.active { border-left: 3px solid var(--ey-yellow); }
        .main-content { margin-left: 260px; padding: 30px; }
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s;
            height: 100%;
        }
        .stat-card:hover { transform: translateY(-3px); }
        .stat-card.primary { background: linear-gradient(135deg, var(--ey-dark), #3a3a48); color: white; }
        .stat-card.warning { background: linear-gradient(135deg, var(--ey-yellow), #e6cf00); color: var(--ey-dark); }
        .stat-card.success { background: linear-gradient(135deg, #28a745, #20c997); color: white; }
        .stat-card.info { background: linear-gradient(135deg, #17a2b8, #3498db); color: white; }
        .stat-number { font-size: 2rem; font-weight: 700; }
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .card-header { background: white; border-bottom: 1px solid #eee; font-weight: 600; }
        .btn-ey { background: var(--ey-yellow); color: var(--ey-dark); font-weight: 600; border: none; }
        .btn-ey:hover { background: #e6cf00; color: var(--ey-dark); }
        .ey-logo { background: var(--ey-yellow); color: var(--ey-dark); padding: 5px 12px; font-weight: 700; font-size: 1.5rem; }
        .avatar {
            width: 50px; height: 50px;
            background: var(--ey-yellow);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-weight: 600; color: var(--ey-dark); font-size: 1rem;
        }
        .avatar-lg {
            width: 70px; height: 70px;
            font-size: 1.3rem;
        }
        .stagiaire-card {
            border-left: 4px solid var(--ey-yellow);
            transition: all 0.3s;
        }
        .stagiaire-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        .progress { height: 8px; border-radius: 4px; }
        .modal-header { background: var(--ey-dark); color: white; }
        .modal-header .btn-close { filter: invert(1); }
        @media (max-width: 768px) { .sidebar { display: none; } .main-content { margin-left: 0; } }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="text-center mb-4">
            <span class="ey-logo">EY</span>
            <p class="text-white mt-3 mb-1">Espace Encadrant</p>
            <small class="text-white-50"><?php echo htmlspecialchars($user_info['prenom'] . ' ' . $user_info['nom']); ?></small>
        </div>
        <hr class="bg-secondary">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'encadrant.php' ? 'active' : ''; ?>" href="encadrant.php">
                    <i class="bi bi-house me-2"></i> Tableau de bord
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'encadrant-stagiaires.php' ? 'active' : ''; ?>" href="encadrant-stagiaires.php">
                    <i class="bi bi-people me-2"></i> Mes stagiaires
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'encadrant-evaluations.php' ? 'active' : ''; ?>" href="encadrant-evaluations.php">
                    <i class="bi bi-star me-2"></i> Évaluations
                </a>
            </li>
            <!-- Added project management link to encadrant sidebar -->
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'encadrant-projets.php' ? 'active' : ''; ?>" href="encadrant-projets.php">
                    <i class="bi bi-kanban me-2"></i> Gestion Projets
                </a>
            </li>
        </ul>
        <hr class="bg-secondary mt-4">
        <a href="../index.php" class="btn btn-outline-light btn-sm w-100 mb-2">
            <i class="bi bi-arrow-left"></i> Retour au site
        </a>
        <a href="../logout.php" class="btn btn-danger btn-sm w-100">
            <i class="bi bi-box-arrow-right"></i> Déconnexion
        </a>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle me-2"></i> <?php echo $success_msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Bonjour, <?php echo htmlspecialchars($_SESSION['prenom']); ?> !</h2>
                <p class="text-muted mb-0">Gérez et suivez vos stagiaires</p>
            </div>
            <div class="d-flex align-items-center">
                <span class="text-muted me-3"><i class="bi bi-calendar"></i> <?php echo date('d/m/Y'); ?></span>
                <div class="avatar"><?php echo strtoupper(substr($user_info['prenom'], 0, 1) . substr($user_info['nom'], 0, 1)); ?></div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card primary">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 opacity-75">Total stagiaires</p>
                            <p class="stat-number mb-0"><?php echo count($mes_stagiaires); ?></p>
                        </div>
                        <i class="bi bi-people fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card success">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 opacity-75">En cours</p>
                            <p class="stat-number mb-0"><?php echo $stagiaires_actifs; ?></p>
                        </div>
                        <i class="bi bi-person-check fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card warning">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1">Évaluations</p>
                            <p class="stat-number mb-0"><?php echo $total_evaluations; ?></p>
                        </div>
                        <i class="bi bi-clipboard-check fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card info">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 opacity-75">Spécialité</p>
                            <p class="fs-6 fw-bold mb-0"><?php echo htmlspecialchars($user_info['specialite'] ? $user_info['specialite'] : 'Non définie'); ?></p>
                        </div>
                        <i class="bi bi-award fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Aperçu stagiaires -->
        <div class="card" id="stagiaires">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-people me-2"></i> Aperçu de vos stagiaires</span>
                <a href="encadrant-stagiaires.php" class="btn btn-ey btn-sm">
                    <i class="bi bi-arrow-right"></i> Voir tous
                </a>
            </div>
            <div class="card-body">
                <?php if (empty($mes_stagiaires)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-person-x fs-1 text-muted"></i>
                    <h5 class="mt-3">Aucun stagiaire assigné</h5>
                    <p class="text-muted">Vous serez notifié lorsqu'un stagiaire vous sera affecté.</p>
                </div>
                <?php else: ?>
                <div class="row g-4">
                    <?php 
                    $limited_stagiaires = array_slice($mes_stagiaires, 0, 3);
                    foreach ($limited_stagiaires as $s): 
                    ?>
                    <div class="col-md-6">
                        <div class="card stagiaire-card h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar avatar-lg me-3">
                                            <?php echo strtoupper(substr($s['prenom'], 0, 1) . substr($s['nom'], 0, 1)); ?>
                                        </div>
                                        <div>
                                            <h5 class="mb-0"><?php echo htmlspecialchars($s['prenom'] . ' ' . $s['nom']); ?></h5>
                                            <small class="text-muted"><?php echo htmlspecialchars($s['email']); ?></small>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="bg-light rounded p-2 mb-2 small">
                                    <strong><?php echo htmlspecialchars($s['stage_titre']); ?></strong>
                                </div>
                                
                                <a href="encadrant-stagiaires.php" class="btn btn-sm btn-outline-primary w-100">
                                    <i class="bi bi-eye"></i> Voir détails
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
