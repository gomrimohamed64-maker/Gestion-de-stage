<?php
require_once dirname(__FILE__) . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../connexion.php');
    exit;
}

$pdo = getConnection();

// Statistiques détaillées
$stats = [
    'stages_total' => $pdo->query("SELECT COUNT(*) FROM stages")->fetchColumn(),
    'stages_ouverts' => $pdo->query("SELECT COUNT(*) FROM stages WHERE statut = 'ouvert'")->fetchColumn(),
    'candidatures_total' => $pdo->query("SELECT COUNT(*) FROM candidatures")->fetchColumn(),
    'candidatures_attente' => $pdo->query("SELECT COUNT(*) FROM candidatures WHERE statut = 'en_attente'")->fetchColumn(),
    'candidatures_acceptees' => $pdo->query("SELECT COUNT(*) FROM candidatures WHERE statut = 'acceptee'")->fetchColumn(),
    'candidatures_refusees' => $pdo->query("SELECT COUNT(*) FROM candidatures WHERE statut = 'refusee'")->fetchColumn(),
    'stagiaires' => $pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'stagiaire'")->fetchColumn(),
    'encadrants' => $pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'encadrant'")->fetchColumn(),
    'affectations' => $pdo->query("SELECT COUNT(*) FROM affectations")->fetchColumn(),
    'affectations_actives' => $pdo->query("SELECT COUNT(*) FROM affectations WHERE statut = 'en_cours'")->fetchColumn(),
    'evaluations' => $pdo->query("SELECT COUNT(*) FROM evaluations")->fetchColumn(),
];

// Taux de conversion
$taux_conversion = $stats['candidatures_total'] > 0 ? round(($stats['candidatures_acceptees'] / $stats['candidatures_total']) * 100, 1) : 0;

// Stages les plus demandés
$top_stages = $pdo->query("
    SELECT s.id, s.titre, s.departement, COUNT(c.id) as candidatures
    FROM stages s
    LEFT JOIN candidatures c ON s.id = c.stage_id
    GROUP BY s.id
    ORDER BY candidatures DESC
    LIMIT 5
")->fetchAll();

// Encadrants et leurs stagiaires
$encadrants_load = $pdo->query("
    SELECT u.id, u.prenom, u.nom, u.specialite, COUNT(a.id) as stagiaires_assignes
    FROM utilisateurs u
    LEFT JOIN affectations a ON u.id = a.encadrant_id
    WHERE u.role = 'encadrant'
    GROUP BY u.id
    ORDER BY stagiaires_assignes DESC
")->fetchAll();

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapports - Espace Admin EY</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ey-yellow: #ffe600;
            --ey-dark: #2e2e38;
            --ey-gray: #747480;
            --ey-light: #f6f6fa;
        }
        body { font-family: 'Inter', sans-serif; background-color: var(--ey-light); }
        .sidebar {
            background: linear-gradient(180deg, var(--ey-dark) 0%, #1a1a24 100%);
            min-height: 100vh;
            position: fixed;
            width: 260px;
            padding: 20px;
            z-index: 1000;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 5px;
            transition: all 0.3s;
            text-decoration: none;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,230,0,0.15);
        }
        .sidebar .nav-link.active { border-left: 3px solid var(--ey-yellow); }
        .main-content { margin-left: 260px; padding: 30px; }
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            text-align: center;
        }
        .stat-card h6 { color: var(--ey-gray); font-size: 0.9rem; margin-bottom: 10px; }
        .stat-number { font-size: 2.5rem; font-weight: 700; color: var(--ey-dark); }
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .card-header { background: white; border-bottom: 1px solid #eee; font-weight: 600; }
        .btn-ey { background: var(--ey-yellow); color: var(--ey-dark); font-weight: 600; border: none; }
        .btn-ey:hover { background: #e6cf00; color: var(--ey-dark); }
        .ey-logo { background: var(--ey-yellow); color: var(--ey-dark); padding: 5px 12px; font-weight: 700; font-size: 1.5rem; }
        .progress-bar { background: var(--ey-yellow); }
        @media (max-width: 768px) { .sidebar { display: none; } .main-content { margin-left: 0; } }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="text-center mb-4">
            <span class="ey-logo">EY</span>
            <p class="text-white mt-3 mb-1">Administrateur</p>
        </div>
        <hr class="bg-secondary">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="admin.php">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin.php#stages">
                    <i class="bi bi-briefcase me-2"></i> Stages
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin.php#candidatures">
                    <i class="bi bi-file-earmark me-2"></i> Candidatures
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin.php#utilisateurs">
                    <i class="bi bi-people me-2"></i> Utilisateurs
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'admin-rapports.php' ? 'active' : ''; ?>" href="admin-rapports.php">
                    <i class="bi bi-graph-up me-2"></i> Rapports
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin.php#affectations">
                    <i class="bi bi-link-45deg me-2"></i> Affectations
                </a>
            </li>
        </ul>
        <hr class="bg-secondary mt-4">
        <a href="../index.php" class="btn btn-outline-light btn-sm w-100 mb-2">
            <i class="bi bi-arrow-left"></i> Retour au site
        </a>
        <a href="../logout.php" class="btn btn-danger btn-sm w-100">
            <i class="bi bi-box-arrow-right"></i> Déconnexion
        </a>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <h2 class="mb-4"><i class="bi bi-graph-up me-2"></i> Rapports et Statistiques</h2>

        <!-- KPIs Principaux -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <h6><i class="bi bi-briefcase me-2"></i> Stages</h6>
                    <p class="stat-number"><?php echo $stats['stages_ouverts']; ?>/<?php echo $stats['stages_total']; ?></p>
                    <small class="text-muted">Ouverts / Total</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <h6><i class="bi bi-file-earmark me-2"></i> Candidatures</h6>
                    <p class="stat-number"><?php echo $stats['candidatures_total']; ?></p>
                    <small class="text-muted"><?php echo $stats['candidatures_attente']; ?> en attente</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <h6><i class="bi bi-percent me-2"></i> Taux d'acceptation</h6>
                    <p class="stat-number"><?php echo $taux_conversion; ?>%</p>
                    <div class="progress mt-2">
                        <div class="progress-bar" style="width: <?php echo $taux_conversion; ?>%"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <h6><i class="bi bi-person-check me-2"></i> Affectations</h6>
                    <p class="stat-number"><?php echo $stats['affectations_actives']; ?></p>
                    <small class="text-muted">En cours</small>
                </div>
            </div>
        </div>

        <!-- Détails par type -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-light">Candidatures</div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-3">
                            <span>Acceptées</span>
                            <strong class="text-success"><?php echo $stats['candidatures_acceptees']; ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-3">
                            <span>En attente</span>
                            <strong class="text-warning"><?php echo $stats['candidatures_attente']; ?></strong>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Refusées</span>
                            <strong class="text-danger"><?php echo $stats['candidatures_refusees']; ?></strong>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-light">Utilisateurs</div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-3">
                            <span>Stagiaires</span>
                            <strong><?php echo $stats['stagiaires']; ?></strong>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Encadrants</span>
                            <strong><?php echo $stats['encadrants']; ?></strong>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-light">Évaluations</div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <span>Total</span>
                            <strong><?php echo $stats['evaluations']; ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stages les plus demandés -->
        <div class="card mb-4">
            <div class="card-header">
                <i class="bi bi-fire me-2"></i> Stages les plus demandés
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Stage</th>
                                <th>Département</th>
                                <th class="text-end">Candidatures</th>
                                <th class="text-end">%</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_stages as $stage): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($stage['titre']); ?></strong></td>
                                <td><?php echo htmlspecialchars($stage['departement']); ?></td>
                                <td class="text-end"><?php echo $stage['candidatures']; ?></td>
                                <td class="text-end">
                                    <?php 
                                    $percent = $stats['candidatures_total'] > 0 ? round(($stage['candidatures'] / $stats['candidatures_total']) * 100, 1) : 0;
                                    echo $percent . '%';
                                    ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Charge des encadrants -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-people me-2"></i> Charge de travail des encadrants
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Encadrant</th>
                                <th>Spécialité</th>
                                <th class="text-end">Stagiaires assignés</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($encadrants_load as $encadrant): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($encadrant['prenom'] . ' ' . $encadrant['nom']); ?></strong></td>
                                <td><?php echo htmlspecialchars($encadrant['specialite'] ?? 'Non définie'); ?></td>
                                <td class="text-end">
                                    <span class="badge bg-info"><?php echo $encadrant['stagiaires_assignes']; ?></span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
