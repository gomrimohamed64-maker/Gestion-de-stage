<?php
require_once dirname(__FILE__) . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'encadrant') {
    header('Location: ../connexion.php');
    exit;
}

$pdo = getConnection();
$encadrant_id = $_SESSION['user_id'];

// Récupérer infos encadrant
$user_stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$user_stmt->execute([$encadrant_id]);
$user_info = $user_stmt->fetch();

// Mes stagiaires
$stagiaires = $pdo->prepare("
    SELECT a.*, u.nom, u.prenom, u.email, u.telephone, 
           s.titre as stage_titre, s.departement, s.date_debut, s.date_fin, 
           a.statut as affectation_statut
    FROM affectations a
    JOIN utilisateurs u ON a.stagiaire_id = u.id
    JOIN stages s ON a.stage_id = s.id
    WHERE a.encadrant_id = ?
    ORDER BY a.date_affectation DESC
");
$stagiaires->execute([$encadrant_id]);
$mes_stagiaires = $stagiaires->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Stagiaires - EY</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ey-yellow: #ffe600;
            --ey-dark: #2e2e38;
            --ey-gray: #747480;
            --ey-light: #f6f6fa;
        }
        body { font-family: 'Inter', sans-serif; background-color: var(--ey-light); }
        .sidebar {
            background: linear-gradient(180deg, var(--ey-dark) 0%, #1a1a24 100%);
            min-height: 100vh;
            position: fixed;
            width: 260px;
            padding: 20px;
            z-index: 1000;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 5px;
            transition: all 0.3s;
            text-decoration: none;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,230,0,0.15);
        }
        .sidebar .nav-link.active { border-left: 3px solid var(--ey-yellow); }
        .main-content { margin-left: 260px; padding: 30px; }
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .card-header { background: white; border-bottom: 1px solid #eee; font-weight: 600; }
        .btn-ey { background: var(--ey-yellow); color: var(--ey-dark); font-weight: 600; border: none; }
        .btn-ey:hover { background: #e6cf00; color: var(--ey-dark); }
        .ey-logo { background: var(--ey-yellow); color: var(--ey-dark); padding: 5px 12px; font-weight: 700; font-size: 1.5rem; }
        .avatar { width: 50px; height: 50px; background: var(--ey-yellow); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; color: var(--ey-dark); }
        .stagiaire-card { border-left: 4px solid var(--ey-yellow); transition: all 0.3s; }
        .stagiaire-card:hover { transform: translateY(-5px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
        @media (max-width: 768px) { .sidebar { display: none; } .main-content { margin-left: 0; } }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <div class="text-center mb-4">
            <span class="ey-logo">EY</span>
            <p class="text-white mt-3 mb-1">Espace Encadrant</p>
            <small class="text-white-50"><?php echo htmlspecialchars($user_info['prenom'] . ' ' . $user_info['nom']); ?></small>
        </div>
        <hr class="bg-secondary">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="encadrant.php">
                    <i class="bi bi-house me-2"></i> Tableau de bord
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="encadrant-stagiaires.php">
                    <i class="bi bi-people me-2"></i> Mes stagiaires
                    <span class="badge bg-warning text-dark float-end"><?php echo count($mes_stagiaires); ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="encadrant-evaluations.php">
                    <i class="bi bi-clipboard-check me-2"></i> Évaluations
                </a>
            </li>
        </ul>
        <hr class="bg-secondary mt-4">
        <a href="../index.php" class="btn btn-outline-light btn-sm w-100 mb-2">
            <i class="bi bi-arrow-left"></i> Retour au site
        </a>
        <a href="../logout.php" class="btn btn-danger btn-sm w-100">
            <i class="bi bi-box-arrow-right"></i> Déconnexion
        </a>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Mes Stagiaires</h2>
                <p class="text-muted mb-0">Gestion et suivi de vos stagiaires</p>
            </div>
            <div class="d-flex align-items-center">
                <span class="text-muted me-3"><i class="bi bi-calendar"></i> <?php echo date('d/m/Y'); ?></span>
                <div class="avatar"><?php echo strtoupper(substr($user_info['prenom'], 0, 1) . substr($user_info['nom'], 0, 1)); ?></div>
            </div>
        </div>

        <!-- Liste des stagiaires -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-people me-2"></i> Liste complète des stagiaires
                <span class="badge bg-dark float-end"><?php echo count($mes_stagiaires); ?> stagiaire(s)</span>
            </div>
            <div class="card-body">
                <?php if (empty($mes_stagiaires)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-person-x fs-1 text-muted"></i>
                    <h5 class="mt-3">Aucun stagiaire assigné</h5>
                    <p class="text-muted">Vous serez notifié lorsqu'un stagiaire vous sera affecté.</p>
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Stagiaire</th>
                                <th>Email</th>
                                <th>Téléphone</th>
                                <th>Stage</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($mes_stagiaires as $s): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar me-2" style="width: 35px; height: 35px;">
                                            <?php echo strtoupper(substr($s['prenom'], 0, 1) . substr($s['nom'], 0, 1)); ?>
                                        </div>
                                        <strong><?php echo htmlspecialchars($s['prenom'] . ' ' . $s['nom']); ?></strong>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($s['email']); ?></td>
                                <td><?php echo htmlspecialchars($s['telephone'] ?? '-'); ?></td>
                                <td><span class="badge bg-secondary"><?php echo htmlspecialchars($s['stage_titre']); ?></span></td>
                                <td>
                                    <span class="badge bg-<?php echo $s['affectation_statut'] === 'en_cours' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($s['affectation_statut']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-ey" data-bs-toggle="modal" data-bs-target="#evalModal<?php echo $s['id']; ?>">
                                        <i class="bi bi-clipboard-check"></i> Évaluer
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
