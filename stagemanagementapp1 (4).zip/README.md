# EY Stage Management Platform - Plateforme de Gestion des Stages

Une plateforme moderne et complète de gestion des offres de stage, candidatures et affectations pour EY Maroc.

## Caractéristiques principales

### Pour les Stagiaires
- 📋 **Tableau de bord personnel** - Vue d'ensemble de votre parcours
- 🎯 **Gestion des candidatures** - Suivi du statut de vos candidatures
- 📝 **Profil personnel** - Modifier vos informations
- ⭐ **Évaluations** - Consultation des évaluations reçues

### Pour les Encadrants
- 👥 **Gestion des stagiaires** - Liste complète des stagiaires affectés
- 📊 **Évaluations** - Formulaires d'évaluation intuitifs
- 📈 **Suivi de progression** - Visualisation de la progression des stages
- 📋 **Historique** - Consultation des évaluations précédentes

### Pour les Administrateurs
- 🏢 **Gestion des stages** - Création, modification et suppression des offres
- 👤 **Gestion des utilisateurs** - Créer et gérer tous les types de comptes
- 📊 **Candidatures** - Traitement et assignation des candidatures
- 📈 **Statistiques** - Dashboard complet avec KPIs
- 🔄 **Affectations** - Gestion des affectations stagiaire-encadrant

## Structure du projet

```
.
├── dashboards/
│   ├── admin.php                 # Dashboard administrateur
│   ├── stagiaire.php             # Dashboard stagiaire
│   ├── stagiaire-candidatures.php # Gestion des candidatures
│   ├── stagiaire-profil.php      # Profil du stagiaire
│   ├── encadrant.php             # Dashboard encadrant
│   ├── encadrant-stagiaires.php  # Gestion des stagiaires
│   └── encadrant-evaluations.php # Gestion des évaluations
├── includes/
│   ├── header.php                # En-tête avec navigation
│   └── footer.php                # Pied de page
├── assets/
│   └── css/
│       └── style.css             # Styles professionnels EY
├── config/
│   └── database.php              # Configuration de la base de données
├── index.php                      # Page d'accueil
├── inscription.php                # Formulaire d'inscription
├── connexion.php                  # Formulaire de connexion
├── stages.php                     # Liste des stages
├── stage-detail.php               # Détail d'un stage
├── dashboard.php                  # Redirection dashboard
└── logout.php                     # Déconnexion
```

## Installation

### Prérequis
- PHP 7.4+
- MySQL 5.7+
- Serveur web (Apache, Nginx, etc.)

### Étapes d'installation

1. **Cloner le projet**
```bash
git clone https://github.com/ey/stage-management.git
cd stage-management
```

2. **Configurer la base de données**
```bash
# Importer la structure SQL
mysql -u root -p < scripts/database.sql
```

3. **Configurer les variables de connexion**
Modifier `config/database.php` avec vos paramètres:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'votre_user');
define('DB_PASS', 'votre_password');
define('DB_NAME', 'ey_stages');
```

4. **Démarrer le serveur**
```bash
php -S localhost:8000
```

5. **Accéder à l'application**
Ouvrir `http://localhost:8000` dans votre navigateur

## Comptes de démonstration

### Admin
- Email: `admin@ey.com`
- Mot de passe: `password`

### Encadrant
- Email: `marie.dupont@ey.com`
- Mot de passe: `password`

## Sécurité

- Authentification par email/mot de passe avec hashage bcrypt
- Protection des sessions
- Validation des entrées
- Protection contre les injections SQL
- CSRF protection (à implémenter)

## Technologies utilisées

- **Backend**: PHP 7.4+
- **Frontend**: Bootstrap 5.3, HTML5, CSS3
- **Base de données**: MySQL
- **Icons**: Bootstrap Icons
- **Fonts**: Inter (Google Fonts)

## Améliorations futures

- [ ] Authentification OAuth (Google, LinkedIn)
- [ ] Notifications email
- [ ] Upload de documents (CV, lettres de motivation)
- [ ] Système de notes et avis
- [ ] Rapports PDF
- [ ] Intégration avec systèmes RH
- [ ] Application mobile
- [ ] API REST complète
- [ ] Tests automatisés
- [ ] Déploiement continu

## Support

Pour toute question ou problème, veuillez contacter:
- 📧 stages@ey.ma
- 📞 +212 5 22 95 79 00

## Licence

Propriétaire © 2026 EY Maroc. Tous droits réservés.

---

**Plateforme conçue avec ❤️ pour les talents de demain**
