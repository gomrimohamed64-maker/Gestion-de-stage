<?php
require_once 'config/database.php';
include 'includes/header.php';

$query = isset($_GET['q']) ? htmlspecialchars($_GET['q']) : '';
$results = [];

if (!empty($query)) {
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("
            SELECT * FROM stages 
            WHERE (titre LIKE ? OR description LIKE ? OR departement LIKE ? OR lieu LIKE ?) 
            AND statut = 'ouvert'
            ORDER BY date_creation DESC
        ");
        $searchTerm = '%' . $query . '%';
        $stmt->execute([$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        $results = $stmt->fetchAll();
    } catch (PDOException $e) {
        $error = "Erreur lors de la recherche.";
    }
}
?>

<section class="py-5">
    <div class="container">
        <div class="mb-4">
            <h2 class="fw-bold mb-2">Résultats de recherche</h2>
            <p class="text-muted">
                <?php if (!empty($query)): ?>
                    Recherche pour: <strong><?= $query ?></strong> (<?= count($results) ?> résultat<?= count($results) !== 1 ? 's' : '' ?>)
                <?php else: ?>
                    Veuillez entrer un terme de recherche
                <?php endif; ?>
            </p>
        </div>

        <?php if (!empty($query)): ?>
            <?php if (count($results) > 0): ?>
                <div class="row g-4">
                    <?php foreach ($results as $stage): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card card-stage h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <span class="badge bg-dark"><?= htmlspecialchars($stage['departement']) ?></span>
                                    <span class="badge bg-success"><?= $stage['places_disponibles'] ?> place(s)</span>
                                </div>
                                <h5 class="card-title fw-bold mb-3"><?= htmlspecialchars($stage['titre']) ?></h5>
                                <p class="card-text text-muted small"><?= substr(htmlspecialchars($stage['description']), 0, 120) ?>...</p>
                                <hr>
                                <div class="d-flex justify-content-between text-muted small">
                                    <span><i class="bi bi-clock me-1"></i> <?= htmlspecialchars($stage['duree']) ?></span>
                                    <span><i class="bi bi-geo-alt me-1"></i> <?= htmlspecialchars($stage['lieu'] ?? 'Tunis') ?></span>
                                </div>
                            </div>
                            <div class="card-footer bg-white border-0 pt-0">
                                <a href="stage-detail.php?id=<?= $stage['id'] ?>" class="btn btn-ey w-100">
                                    <i class="bi bi-arrow-right me-2"></i> Voir les détails
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info" role="alert">
                    <i class="bi bi-info-circle me-2"></i>
                    Aucun stage ne correspond à votre recherche. <a href="stages.php">Consulter tous les stages</a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
