<?php
require_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Rediriger si déjà connecté
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$redirect = $_GET['redirect'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = getConnection();
    
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $error = "Veuillez remplir tous les champs.";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = ? AND statut = 'actif'");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['mot_de_passe'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['nom'] = $user['nom'];
            $_SESSION['prenom'] = $user['prenom'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            
            // Redirection après connexion
            if ($redirect) {
                header('Location: ' . $redirect);
            } else {
                header('Location: dashboard.php');
            }
            exit;
        } else {
            $error = "Email ou mot de passe incorrect.";
        }
    }
}

include 'includes/header.php';
?>

<div class="min-vh-100 d-flex align-items-center" style="background: linear-gradient(135deg, #f6f6fa 0%, #e8e8ef 100%);">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card border-0 shadow-lg overflow-hidden" style="border-radius: 20px;">
                    <div class="row g-0">
                        <!-- Left Side - Branding -->
                        <div class="col-lg-5 d-none d-lg-block" style="background: linear-gradient(135deg, #2e2e38 0%, #1a1a24 100%);">
                            <div class="p-5 h-100 d-flex flex-column justify-content-center text-white">
                                <div class="mb-4">
                                    <span class="ey-logo fs-2">EY</span>
                                </div>
                                <h2 class="fw-bold mb-3">Bienvenue sur<br>la plateforme de stages</h2>
                                <p class="opacity-75 mb-4">Connectez-vous pour accéder à votre espace personnel et gérer vos candidatures.</p>
                                <div class="mt-auto">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="rounded-circle bg-warning p-2 me-3">
                                            <i class="bi bi-check-lg text-dark"></i>
                                        </div>
                                        <span class="opacity-75">Accédez à vos candidatures</span>
                                    </div>
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="rounded-circle bg-warning p-2 me-3">
                                            <i class="bi bi-check-lg text-dark"></i>
                                        </div>
                                        <span class="opacity-75">Suivez vos stages en cours</span>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <div class="rounded-circle bg-warning p-2 me-3">
                                            <i class="bi bi-check-lg text-dark"></i>
                                        </div>
                                        <span class="opacity-75">Consultez vos évaluations</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Right Side - Form -->
                        <div class="col-lg-7">
                            <div class="p-5">
                                <div class="text-center mb-4 d-lg-none">
                                    <span class="ey-logo fs-2">EY</span>
                                </div>
                                
                                <h3 class="fw-bold mb-1">Connexion</h3>
                                <p class="text-muted mb-4">Entrez vos identifiants pour accéder à votre compte</p>
                                
                                <?php if ($error): ?>
                                <div class="alert alert-danger d-flex align-items-center">
                                    <i class="bi bi-exclamation-circle me-2"></i>
                                    <?= htmlspecialchars($error) ?>
                                </div>
                                <?php endif; ?>
                                
                                <form method="POST">
                                    <?php if ($redirect): ?>
                                    <input type="hidden" name="redirect" value="<?= htmlspecialchars($redirect) ?>">
                                    <?php endif; ?>
                                    
                                    <div class="mb-4">
                                        <label class="form-label fw-bold">
                                            <i class="bi bi-envelope me-1 text-warning"></i> Adresse email
                                        </label>
                                        <input type="email" name="email" class="form-control form-control-lg" placeholder="votre@email.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                                    </div>
                                    
                                    <div class="mb-4">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <label class="form-label fw-bold mb-0">
                                                <i class="bi bi-lock me-1 text-warning"></i> Mot de passe
                                            </label>
                                            <a href="#" class="small text-muted">Mot de passe oublié?</a>
                                        </div>
                                        <input type="password" name="password" class="form-control form-control-lg mt-2" placeholder="••••••••" required>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="remember">
                                            <label class="form-check-label text-muted" for="remember">
                                                Se souvenir de moi
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-ey btn-lg w-100 mb-4">
                                        <i class="bi bi-box-arrow-in-right me-2"></i> Se connecter
                                    </button>
                                </form>
                                
                                <div class="text-center">
                                    <p class="text-muted mb-0">
                                        Pas encore de compte? 
                                        <a href="inscription.php" class="fw-bold text-decoration-none" style="color: #2e2e38;">Créer un compte</a>
                                    </p>
                                </div>
                                <!-- Removed demo accounts section -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
