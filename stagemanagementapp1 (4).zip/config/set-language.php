<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['language'])) {
    $language = htmlspecialchars($_POST['language']);
    
    // Validate language choice
    $allowed_languages = ['fr', 'en', 'ar'];
    if (in_array($language, $allowed_languages)) {
        $_SESSION['language'] = $language;
        setcookie('language', $language, time() + (30 * 24 * 60 * 60), '/'); // 30 days
        echo json_encode(['success' => true, 'language' => $language]);
    }
}
?>
