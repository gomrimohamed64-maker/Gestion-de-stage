<?php
require_once 'config/database.php';
include 'includes/header.php';
?>

<!-- Hero Section -->
<section class="bg-dark text-white py-5">
    <div class="container">
        <h1 class="fw-bold mb-3">Questions Fréquemment Posées</h1>
        <p class="lead opacity-75 mb-0">Trouvez les réponses à vos questions sur nos stages et le processus de candidature</p>
    </div>
</section>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-8">
            <div class="accordion" id="faqAccordion">
                <!-- Created comprehensive FAQ section with collapsible items -->
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                            <i class="bi bi-question-circle me-2 text-warning"></i> Qui peut postuler à un stage chez EY ?
                        </button>
                    </h2>
                    <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            Nos stages sont ouverts à tous les étudiants de niveau BAC+3 ou supérieur, en particulier ceux poursuivant des études en informatique, gestion, audit ou domaines connexes. Un très bon niveau académique et une maîtrise du français et de l'anglais sont des atouts majeurs.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                            <i class="bi bi-question-circle me-2 text-warning"></i> Quelle est la durée d'un stage ?
                        </button>
                    </h2>
                    <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            La plupart de nos stages durent entre 3 et 6 mois, en fonction de vos études et de nos besoins. Nous offrons des stages en temps plein pendant l'été ou des périodes partielles pendant le trimestre académique.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                            <i class="bi bi-question-circle me-2 text-warning"></i> Quelle est la rémunération ?
                        </button>
                    </h2>
                    <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            EY offre une rémunération compétitive pour tous ses stagiaires, généralement entre 400 et 800 TND par mois selon le profil, le niveau et la durée du stage. Des avantages supplémentaires comme les primes de déplacement peuvent être proposés.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                            <i class="bi bi-question-circle me-2 text-warning"></i> Comment postuler à un stage ?
                        </button>
                    </h2>
                    <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            Vous pouvez postuler directement via notre plateforme en ligne après vous être inscrit. Préparez votre CV, votre lettre de motivation et vos relevés de notes. Le processus comprend généralement une première vérification de profil suivie d'un entretien.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                            <i class="bi bi-question-circle me-2 text-warning"></i> Quels sont les domaines d'expertise proposés ?
                        </button>
                    </h2>
                    <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            Nous proposons des stages dans plusieurs domaines : Audit, Consulting, Informatique (Développement, Data Science, DevOps), Fiscal et Transactions. Chaque domaine offre des opportunités de développement professionnelles uniques.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq6">
                            <i class="bi bi-question-circle me-2 text-warning"></i> Y a-t-il des perspectives d'embauche après le stage ?
                        </button>
                    </h2>
                    <div id="faq6" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            Absolument ! De nombreux stagiaires qui excellents dans leurs stages reçoivent des offres de CDI. Nous valorisons les talents qui montrent de l'engagement et une volonté d'apprentissage. Le stage est une excellente opportunité de nous montrer vos capacités.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq7">
                            <i class="bi bi-question-circle me-2 text-warning"></i> Quels sont les avantages de rejoindre EY comme stagiaire ?
                        </button>
                    </h2>
                    <div id="faq7" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            En tant que stagiaire chez EY, vous bénéficiez d'une formation professionnelle de qualité, d'un mentorat personnalisé, d'une exposition à des projets réels, d'une rémunération compétitive et d'un environnement inclusif et collaboratif. Vous aurez également accès à nos programmes de développement continu.
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Contact CTA -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-lg mb-4">
                <div class="card-body p-4 text-center">
                    <i class="bi bi-chat-dots" style="font-size: 3rem; color: #ffe600;"></i>
                    <h5 class="fw-bold mt-3 mb-2">Vous n'avez pas trouvé votre réponse ?</h5>
                    <p class="text-muted mb-3">Notre équipe est disponible pour répondre à vos questions</p>
                    <a href="contact.php" class="btn btn-ey btn-sm w-100">
                        <i class="bi bi-envelope me-2"></i> Nous contacter
                    </a>
                </div>
            </div>

            <!-- FAQ Tips -->
            <h5 class="fw-bold mb-3">Conseils utiles</h5>
            <div class="list-group">
                <a href="#" class="list-group-item list-group-item-action">
                    <i class="bi bi-check-circle text-success me-2"></i> Mettez à jour votre profil régulièrement
                </a>
                <a href="#" class="list-group-item list-group-item-action">
                    <i class="bi bi-check-circle text-success me-2"></i> Préparez votre CV et lettre de motivation
                </a>
                <a href="#" class="list-group-item list-group-item-action">
                    <i class="bi bi-check-circle text-success me-2"></i> Activez les notifications pour les nouveaux stages
                </a>
                <a href="#" class="list-group-item list-group-item-action">
                    <i class="bi bi-check-circle text-success me-2"></i> Consultez nos offres régulièrement
                </a>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
