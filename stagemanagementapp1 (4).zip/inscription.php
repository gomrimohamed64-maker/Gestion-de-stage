<?php
require_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Rediriger si déjà connecté
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = getConnection();
    
    $nom = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    
    // Validation
    if (empty($nom) || empty($prenom) || empty($email) || empty($password)) {
        $error = "Veuillez remplir tous les champs obligatoires.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Adresse email invalide.";
    } elseif (strlen($password) < 6) {
        $error = "Le mot de passe doit contenir au moins 6 caractères.";
    } elseif ($password !== $confirm) {
        $error = "Les mots de passe ne correspondent pas.";
    } else {
        // Vérifier si l'email existe
        $stmt = $pdo->prepare("SELECT id FROM utilisateurs WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "Cette adresse email est déjà utilisée.";
        } else {
            // Inscription
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, prenom, email, telephone, mot_de_passe, role) VALUES (?, ?, ?, ?, ?, 'stagiaire')");
            if ($stmt->execute([$nom, $prenom, $email, $telephone, $hash])) {
                $message = "Inscription réussie! Vous pouvez maintenant vous connecter.";
            } else {
                $error = "Une erreur est survenue lors de l'inscription.";
            }
        }
    }
}

include 'includes/header.php';
?>

<div class="min-vh-100 d-flex align-items-center" style="background: linear-gradient(135deg, #f6f6fa 0%, #e8e8ef 100%);">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card border-0 shadow-lg overflow-hidden" style="border-radius: 20px;">
                    <div class="row g-0">
                        <!-- Left Side - Form -->
                        <div class="col-lg-7 order-lg-1 order-2">
                            <div class="p-5">
                                <div class="text-center mb-4 d-lg-none">
                                    <span class="ey-logo fs-2">EY</span>
                                </div>
                                
                                <h3 class="fw-bold mb-1">Créer un compte</h3>
                                <p class="text-muted mb-4">Rejoignez EY et lancez votre carrière</p>
                                
                                <?php if ($message): ?>
                                <div class="alert alert-success d-flex align-items-center">
                                    <i class="bi bi-check-circle me-2"></i>
                                    <?= htmlspecialchars($message) ?>
                                    <a href="connexion.php" class="ms-auto btn btn-sm btn-success">Se connecter</a>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($error): ?>
                                <div class="alert alert-danger d-flex align-items-center">
                                    <i class="bi bi-exclamation-circle me-2"></i>
                                    <?= htmlspecialchars($error) ?>
                                </div>
                                <?php endif; ?>
                                
                                <form method="POST">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label fw-bold">
                                                <i class="bi bi-person me-1 text-warning"></i> Nom *
                                            </label>
                                            <input type="text" name="nom" class="form-control form-control-lg" placeholder="Votre nom" required value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label fw-bold">
                                                <i class="bi bi-person me-1 text-warning"></i> Prénom *
                                            </label>
                                            <input type="text" name="prenom" class="form-control form-control-lg" placeholder="Votre prénom" required value="<?= htmlspecialchars($_POST['prenom'] ?? '') ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">
                                            <i class="bi bi-envelope me-1 text-warning"></i> Adresse email *
                                        </label>
                                        <input type="email" name="email" class="form-control form-control-lg" placeholder="votre@email.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">
                                            <i class="bi bi-telephone me-1 text-warning"></i> Téléphone
                                        </label>
                                        <input type="tel" name="telephone" class="form-control form-control-lg" placeholder="06 XX XX XX XX" value="<?= htmlspecialchars($_POST['telephone'] ?? '') ?>">
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label fw-bold">
                                                <i class="bi bi-lock me-1 text-warning"></i> Mot de passe *
                                            </label>
                                            <input type="password" name="password" class="form-control form-control-lg" placeholder="••••••••" required minlength="6">
                                            <small class="text-muted">Minimum 6 caractères</small>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label fw-bold">
                                                <i class="bi bi-lock-fill me-1 text-warning"></i> Confirmer *
                                            </label>
                                            <input type="password" name="confirm_password" class="form-control form-control-lg" placeholder="••••••••" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="terms" required>
                                            <label class="form-check-label text-muted small" for="terms">
                                                J'accepte les <a href="#" class="text-decoration-none">conditions d'utilisation</a> et la <a href="#" class="text-decoration-none">politique de confidentialité</a>
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-ey btn-lg w-100 mb-4">
                                        <i class="bi bi-person-plus me-2"></i> Créer mon compte
                                    </button>
                                </form>
                                
                                <div class="text-center">
                                    <p class="text-muted mb-0">
                                        Déjà inscrit? 
                                        <a href="connexion.php" class="fw-bold text-decoration-none" style="color: #2e2e38;">Se connecter</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Right Side - Branding -->
                        <div class="col-lg-5 d-none d-lg-block order-lg-2 order-1" style="background: linear-gradient(135deg, #2e2e38 0%, #1a1a24 100%);">
                            <div class="p-5 h-100 d-flex flex-column justify-content-center text-white">
                                <div class="mb-4">
                                    <span class="ey-logo fs-2">EY</span>
                                </div>
                                <h2 class="fw-bold mb-3">Lancez votre carrière avec EY</h2>
                                <p class="opacity-75 mb-4">Créez votre compte pour accéder à nos offres de stage et postuler en quelques clics.</p>
                                
                                <div class="mt-4">
                                    <div class="d-flex align-items-center mb-4">
                                        <div class="rounded-circle bg-warning text-dark p-3 me-3 d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                            <i class="bi bi-1-circle-fill fs-5"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0">Créez votre profil</h6>
                                            <small class="opacity-50">Quelques informations suffisent</small>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center mb-4">
                                        <div class="rounded-circle bg-warning text-dark p-3 me-3 d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                            <i class="bi bi-2-circle-fill fs-5"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0">Explorez les offres</h6>
                                            <small class="opacity-50">Trouvez le stage idéal</small>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <div class="rounded-circle bg-warning text-dark p-3 me-3 d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                            <i class="bi bi-3-circle-fill fs-5"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0">Postulez facilement</h6>
                                            <small class="opacity-50">CV + lettre de motivation</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
